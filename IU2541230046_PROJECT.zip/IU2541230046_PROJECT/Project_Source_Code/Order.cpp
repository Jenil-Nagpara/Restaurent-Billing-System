/*
 * Order.cpp
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 */
#include "Order.h"
#include "BillingException.h"
#include "InputHelper.h"

#include <iostream>
#include <iomanip>
#include <sstream>

Order::Order()
    : orderId(0), customerId(0), itemIds(nullptr), quantities(nullptr),
      unitPrices(nullptr), itemCount(0), capacity(0), total(0.0),
      billed(false), dateTime("") {}

Order::Order(int oid, int cid)
    : orderId(oid), customerId(cid), itemIds(nullptr), quantities(nullptr),
      unitPrices(nullptr), itemCount(0), capacity(0), total(0.0),
      billed(false), dateTime(InputHelper::nowString()) {}

Order::Order(const Order& other)
    : itemIds(nullptr), quantities(nullptr), unitPrices(nullptr) {
    copyFrom(other);
}

Order& Order::operator=(const Order& other) {
    if (this != &other) {          // guard against self-assignment
        release();
        copyFrom(other);
    }
    return *this;
}

Order::~Order() {
#ifdef DEBUG_TRACE
    std::cerr << "[trace] ~Order " << orderId << " (freeing arrays)\n";
#endif
    release();
}

void Order::release() {
    delete[] itemIds;
    delete[] quantities;
    delete[] unitPrices;
    itemIds = nullptr; quantities = nullptr; unitPrices = nullptr;
}

void Order::copyFrom(const Order& o) {
    orderId = o.orderId;  customerId = o.customerId;
    itemCount = o.itemCount;  capacity = o.capacity;
    total = o.total;  billed = o.billed;  dateTime = o.dateTime;
    if (capacity > 0) {
        itemIds    = new int[capacity];
        quantities = new int[capacity];
        unitPrices = new double[capacity];
        for (int i = 0; i < itemCount; ++i) {
            itemIds[i] = o.itemIds[i];
            quantities[i] = o.quantities[i];
            unitPrices[i] = o.unitPrices[i];
        }
    } else {
        itemIds = nullptr; quantities = nullptr; unitPrices = nullptr;
    }
}

void Order::grow() {
    int newCap = (capacity == 0) ? 4 : capacity * 2;
    int*    ni = new int[newCap];
    int*    nq = new int[newCap];
    double* np = new double[newCap];
    for (int i = 0; i < itemCount; ++i) {
        ni[i] = itemIds[i];  nq[i] = quantities[i];  np[i] = unitPrices[i];
    }
    delete[] itemIds;  delete[] quantities;  delete[] unitPrices;
    itemIds = ni;  quantities = nq;  unitPrices = np;
    capacity = newCap;
}

void Order::addItem(int itemId, int qty, double unitPrice) {
    if (qty < 1 || qty > MAX_QTY_PER_LINE)
        throw ValidationException("Quantity must be between 1 and 50.");
    if (unitPrice <= 0)
        throw ValidationException("Invalid unit price.");

    for (int i = 0; i < itemCount; ++i) {          // same item again -> add quantity
        if (itemIds[i] == itemId) {
            if (quantities[i] + qty > MAX_QTY_PER_LINE)
                throw ValidationException("Maximum 50 units of one item per order.");
            quantities[i] += qty;
            calculateTotal();
            return;
        }
    }
    if (itemCount == capacity) grow();
    itemIds[itemCount] = itemId;
    quantities[itemCount] = qty;
    unitPrices[itemCount] = unitPrice;
    ++itemCount;
    calculateTotal();
}

double Order::calculateTotal() {
    double sum = 0.0;
    for (int i = 0; i < itemCount; ++i) sum += quantities[i] * unitPrices[i];
    total = InputHelper::round2(sum);
    return total;
}

void Order::printHeader() {
    std::cout << "+--------+-------------+------------------+-------+------------+----------+\n"
              << "| Order  | Customer ID | Date / Time      | Lines | Total (Rs) | Status   |\n"
              << "+--------+-------------+------------------+-------+------------+----------+\n";
}

void Order::display() const {
    std::cout << "| " << std::left << std::setw(6) << orderId
              << " | " << std::setw(11) << customerId
              << " | " << std::setw(16) << dateTime
              << " | " << std::setw(5) << itemCount
              << " | " << std::right << std::fixed << std::setprecision(2) << std::setw(10) << total
              << " | " << std::left << std::setw(8) << (billed ? "Billed" : "Open") << " |\n";
}

std::string Order::toFileString() const {
    std::ostringstream os;
    os << orderId << "|" << customerId << "|" << dateTime << "|" << (billed ? 1 : 0) << "|";
    for (int i = 0; i < itemCount; ++i) {
        if (i) os << ";";
        os << itemIds[i] << ":" << quantities[i] << ":" << std::fixed << std::setprecision(2) << unitPrices[i];
    }
    return os.str();
}
