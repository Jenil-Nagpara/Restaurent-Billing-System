/*
 * main.cpp
 * ---------------------------------------------------------------------------
 * Project        : Restaurant Billing System   (C++ Guided Project - CPP27)
 * Student Name   : Jenil Nagpara
 * Enrollment No. : IU2541230046
 * Semester       : 3
 * ---------------------------------------------------------------------------
 * main() only creates the system object, shows the menu and calls the system
 * functions. All business logic lives in RestaurantSystem and the entity classes.
 */
#include <iostream>
#include <string>
#include "RestaurantSystem.h"
#include "BillingException.h"
#include "InputHelper.h"

static void printBanner() {
    std::cout << "\n";
    std::cout << "==============================================================\n"
              << "              RESTAURANT BILLING SYSTEM  (C++ OOP)\n"
              << "   Developed by : Jenil Nagpara      Enrollment : IU2541230046\n"
              << "==============================================================\n";
}

static void showMenu() {
    std::cout << "\n=================== MAIN MENU ===================\n"
              << "  1. Add Record\n"
              << "  2. Display Records\n"
              << "  3. Search Record\n"
              << "  4. Update Record\n"
              << "  5. Delete Record\n"
              << "  6. Main Transaction / Process (Order -> Bill -> Payment)\n"
              << "  7. Report\n"
              << "  8. Save / Load\n"
              << "  9. Exit\n"
              << "=================================================\n";
}

int main(int argc, char* argv[]) {
    std::string dataDir = (argc > 1) ? argv[1] : "Data";   // optional custom data folder
    RestaurantSystem system(dataDir);

    printBanner();
    try {
        system.startup();                                  // load existing records
    } catch (const BillingException& e) {
        std::cout << "[ERROR] Startup problem: " << e.what() << "\n";
    }

    bool running = true;
    while (running) {
        try {
            showMenu();
            int choice = InputHelper::readInt("Enter your choice (1-9): ", 1, 9);
            switch (choice) {
                case 1: system.addRecord();       break;
                case 2: system.displayRecords();  break;
                case 3: system.searchRecord();    break;
                case 4: system.updateRecord();    break;
                case 5: system.deleteRecord();    break;
                case 6: system.mainTransaction(); break;
                case 7: system.generateReport();  break;
                case 8: system.saveLoadMenu();    break;
                case 9:
                    system.shutdown();                     // save updated records
                    std::cout << "\nThank you for using the Restaurant Billing System. Goodbye!\n";
                    running = false;
                    break;
            }
        } catch (const InputClosedException&) {
            std::cout << "\n[INFO] Input closed. Saving and exiting...\n";
            try { system.shutdown(); } catch (const BillingException& e) {
                std::cout << "[ERROR] " << e.what() << "\n";
            }
            running = false;
        } catch (const BillingException& e) {
            std::cout << "\n[ERROR] " << e.what() << "\n";    // back to main menu
        } catch (const std::exception& e) {
            std::cout << "\n[UNEXPECTED ERROR] " << e.what() << "\n";
        }
    }
    return 0;
}
