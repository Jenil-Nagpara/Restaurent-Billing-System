/*
 * InputHelper.cpp
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 */
#include "InputHelper.h"
#include "BillingException.h"

#include <iostream>
#include <string>
#include <cctype>
#include <cmath>
#include <ctime>
#include <climits>
#include <algorithm>

namespace InputHelper {

std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
    while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1]))) --b;
    return s.substr(a, b - a);
}

std::string toLower(const std::string& s) {
    std::string r = s;
    std::transform(r.begin(), r.end(), r.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return r;
}

bool containsIgnoreCase(const std::string& hay, const std::string& needle) {
    return toLower(hay).find(toLower(needle)) != std::string::npos;
}

double round2(double v) { return std::round(v * 100.0) / 100.0; }

std::string nowString() {
    std::time_t t = std::time(nullptr);
    std::tm* lt = std::localtime(&t);
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M", lt);
    return std::string(buf);
}

std::string truncate(const std::string& s, size_t width) {
    if (s.size() <= width) return s;
    return s.substr(0, width - 2) + "..";
}

// ------------------------------------------------------------------ validators
bool isValidItemName(const std::string& s) {
    if (s.size() < 2 || s.size() > 30) return false;
    bool hasLetter = false;
    for (unsigned char c : s) {
        if (std::isalpha(c)) hasLetter = true;
        else if (!(std::isdigit(c) || c == ' ' || c == '-' || c == '&' || c == '\'' || c == '.'))
            return false;                                  // '|' is rejected here too
    }
    return hasLetter;
}

bool isValidPersonName(const std::string& s) {
    if (s.size() < 2 || s.size() > 30) return false;
    for (unsigned char c : s)
        if (!(std::isalpha(c) || c == ' ' || c == '.' || c == '-')) return false;
    return true;
}

bool isValidPhone(const std::string& s) {
    if (s.size() != 10) return false;
    for (unsigned char c : s) if (!std::isdigit(c)) return false;
    return s[0] >= '6' && s[0] <= '9';                     // Indian mobile numbers
}

// ------------------------------------------------------------------ reading
std::string readLine(const std::string& prompt) {
    std::cout << prompt;
    std::string line;
    if (!std::getline(std::cin, line)) throw InputClosedException();
    return trim(line);
}

static bool parseInt(const std::string& s, int& out) {
    if (s.empty()) return false;
    try {
        size_t pos = 0;
        long v = std::stol(s, &pos);
        if (pos != s.size() || v < INT_MIN || v > INT_MAX) return false;
        out = static_cast<int>(v);
        return true;
    } catch (...) { return false; }
}

static bool parseDouble(const std::string& s, double& out) {
    if (s.empty()) return false;
    try {
        size_t pos = 0;
        double v = std::stod(s, &pos);
        if (pos != s.size() || !std::isfinite(v)) return false;
        out = v;
        return true;
    } catch (...) { return false; }
}

int readInt(const std::string& prompt, int minV, int maxV) {
    while (true) {
        std::string s = readLine(prompt);
        int v = 0;
        if (parseInt(s, v) && v >= minV && v <= maxV) return v;
        std::cout << "  [!] Invalid input. Enter a whole number between "
                  << minV << " and " << maxV << ".\n";
    }
}

double readDouble(const std::string& prompt, double minV, double maxV) {
    while (true) {
        std::string s = readLine(prompt);
        double v = 0;
        if (parseDouble(s, v) && v >= minV && v <= maxV) return round2(v);
        std::cout << "  [!] Invalid input. Enter a number between "
                  << minV << " and " << maxV << ".\n";
    }
}

bool readYesNo(const std::string& prompt) {
    while (true) {
        std::string s = toLower(readLine(prompt));
        if (s == "y" || s == "yes") return true;
        if (s == "n" || s == "no")  return false;
        std::cout << "  [!] Please enter y or n.\n";
    }
}

std::string readItemName(const std::string& prompt) {
    while (true) {
        std::string s = readLine(prompt);
        if (isValidItemName(s)) return s;
        std::cout << "  [!] Name must be 2-30 characters (letters, digits, space, - & ' .).\n";
    }
}

std::string readPersonName(const std::string& prompt) {
    while (true) {
        std::string s = readLine(prompt);
        if (isValidPersonName(s)) return s;
        std::cout << "  [!] Name must be 2-30 characters, letters and spaces only.\n";
    }
}

std::string readPhone(const std::string& prompt) {
    while (true) {
        std::string s = readLine(prompt);
        if (isValidPhone(s)) return s;
        std::cout << "  [!] Phone must be exactly 10 digits and start with 6, 7, 8 or 9.\n";
    }
}

} // namespace InputHelper
