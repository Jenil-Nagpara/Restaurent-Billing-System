/*
 * Bill.h
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 */
#ifndef BILL_H
#define BILL_H

#include <string>

class Bill {
    int         billId;
    int         orderId;
    double      subtotal;
    double      tax;
    double      total;
    bool        paid;
    std::string dateTime;

public:
    static constexpr double TAX_RATE = 0.05;      // 5 % GST

    Bill();                                       // default constructor
    Bill(int bid, int oid, double sub);           // parameterized (new bill)
    Bill(int bid, int oid, double sub, double taxAmt, double totalAmt,
         bool isPaid, const std::string& dt);     // parameterized (restore from file)
    ~Bill();

    void calculateTotal();                        // tax = subtotal * 5 %, total = subtotal + tax
    void printBill(const std::string& customerName, const std::string& itemLines) const;

    int    getBillId()   const { return billId; }
    int    getOrderId()  const { return orderId; }
    double getSubtotal() const { return subtotal; }
    double getTax()      const { return tax; }
    double getTotal()    const { return total; }
    bool   isPaid()      const { return paid; }
    std::string getDateTime() const { return dateTime; }
    void   markPaid() { paid = true; }

    void display() const;                         // one table row
    std::string toFileString() const;
    static void printHeader();
};

#endif
