/*
 * BillingException.h
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 *
 * Custom exception hierarchy used for Exception Handling.
 */
#ifndef BILLING_EXCEPTION_H
#define BILLING_EXCEPTION_H

#include <stdexcept>
#include <string>

// Base class of every error raised by this project
class BillingException : public std::runtime_error {
public:
    explicit BillingException(const std::string& msg) : std::runtime_error(msg) {}
};

// Invalid user data (bad name, bad price, duplicate record, rule violation ...)
class ValidationException : public BillingException {
public:
    explicit ValidationException(const std::string& msg) : BillingException(msg) {}
};

// Record with the given ID / name does not exist
class NotFoundException : public BillingException {
public:
    explicit NotFoundException(const std::string& msg) : BillingException(msg) {}
};

// Payment could not be processed (low cash, bad card, bad UPI id ...)
class PaymentException : public BillingException {
public:
    explicit PaymentException(const std::string& msg) : BillingException(msg) {}
};

// File could not be opened / written
class FileException : public BillingException {
public:
    explicit FileException(const std::string& msg) : BillingException(msg) {}
};

// Standard input closed (EOF) while waiting for the user
class InputClosedException : public BillingException {
public:
    InputClosedException() : BillingException("Input stream closed.") {}
};

#endif
