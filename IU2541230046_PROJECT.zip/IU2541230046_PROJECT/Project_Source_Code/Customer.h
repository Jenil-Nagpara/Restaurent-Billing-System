/*
 * Customer.h
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 */
#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>

class Customer {
    int         customerId;
    std::string name;
    std::string phone;

public:
    Customer();                                                        // default
    Customer(int id, const std::string& custName, const std::string& custPhone);
    ~Customer();

    int         getCustomerId() const { return customerId; }
    std::string getName()       const { return name; }
    std::string getPhone()      const { return phone; }
    void        setName(const std::string& newName);
    void        setPhone(const std::string& newPhone);

    void        display() const;                 // one table row
    std::string toFileString() const;
    static void printHeader();
};

#endif
