/*
 * Order.h
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 *
 * An Order stores its lines in DYNAMICALLY ALLOCATED arrays (new[] / delete[]).
 * Because the class owns raw memory it implements the Rule of Three:
 * destructor + copy constructor + copy assignment operator.
 */
#ifndef ORDER_H
#define ORDER_H

#include <string>

class Order {
    int     orderId;
    int     customerId;
    int*    itemIds;        // dynamic array : menu item id of each line
    int*    quantities;     // dynamic array : quantity of each line
    double* unitPrices;     // dynamic array : price snapshot at time of ordering
    int     itemCount;
    int     capacity;
    double  total;
    bool    billed;
    std::string dateTime;

    void grow();                              // doubles capacity (new[] / delete[])
    void copyFrom(const Order& other);        // deep copy helper
    void release();                           // delete[] helper

public:
    static constexpr int MAX_QTY_PER_LINE = 50;

    Order();                                  // default constructor
    Order(int oid, int cid);                  // parameterized constructor
    Order(const Order& other);                // copy constructor (deep copy)
    Order& operator=(const Order& other);     // copy assignment (deep copy)
    ~Order();                                 // destructor

    void   addItem(int itemId, int qty, double unitPrice);
    double calculateTotal();                  // recompute total from the lines

    int    getOrderId()    const { return orderId; }
    int    getCustomerId() const { return customerId; }
    int    getItemCount()  const { return itemCount; }
    int    getItemId(int i)    const { return itemIds[i]; }
    int    getQuantity(int i)  const { return quantities[i]; }
    double getUnitPrice(int i) const { return unitPrices[i]; }
    double getTotal()      const { return total; }
    bool   isBilled()      const { return billed; }
    std::string getDateTime() const { return dateTime; }
    void   setBilled(bool b)  { billed = b; }
    void   setDateTime(const std::string& dt) { dateTime = dt; }

    void   display() const;                   // one table row
    std::string toFileString() const;
    static void printHeader();
};

#endif
