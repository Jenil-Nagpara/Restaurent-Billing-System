/*
 * InputHelper.h
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 *
 * Console input + validation utilities. Every read function keeps asking
 * until the user enters valid data (Validation requirement).
 */
#ifndef INPUT_HELPER_H
#define INPUT_HELPER_H

#include <string>

namespace InputHelper {

    // ---------- reading ----------
    std::string readLine(const std::string& prompt);
    int         readInt(const std::string& prompt, int minV, int maxV);
    double      readDouble(const std::string& prompt, double minV, double maxV);
    bool        readYesNo(const std::string& prompt);
    std::string readItemName(const std::string& prompt);
    std::string readPersonName(const std::string& prompt);
    std::string readPhone(const std::string& prompt);

    // ---------- validators (also used by the entity classes) ----------
    bool isValidItemName(const std::string& s);
    bool isValidPersonName(const std::string& s);
    bool isValidPhone(const std::string& s);

    // ---------- string helpers ----------
    std::string trim(const std::string& s);
    std::string toLower(const std::string& s);
    bool        containsIgnoreCase(const std::string& hay, const std::string& needle);
    double      round2(double v);
    std::string nowString();                  // "YYYY-MM-DD HH:MM"
    std::string truncate(const std::string& s, size_t width);
}

#endif
