# UML diagram generator - Restaurant Billing System | Jenil Nagpara | IU2541230046
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, Rectangle
import subprocess, textwrap, html

plt.rcParams["font.family"] = "Liberation Serif"

# ============================ USE CASE DIAGRAM ==============================
fig, ax = plt.subplots(figsize=(15, 10.5))
ax.set_xlim(0, 16); ax.set_ylim(0, 11.2); ax.axis("off")
ax.add_patch(Rectangle((3.0, 0.7), 10.0, 9.3, fill=False, lw=2, ec="#222"))
ax.text(8.0, 9.7, "Restaurant Billing System", ha="center", va="center",
        fontsize=17, fontweight="bold")

def uc(x, y, label, w=3.0, h=0.82):
    ax.add_patch(Ellipse((x, y), w, h, fc="#EAF2FB", ec="#1F4E79", lw=1.5))
    ax.text(x, y, label, ha="center", va="center", fontsize=11.5)
    return (x, y)

def actor(x, y, name):
    ax.add_patch(plt.Circle((x, y + 0.75), 0.25, fc="white", ec="#222", lw=1.8))
    ax.plot([x, x], [y + 0.5, y - 0.25], color="#222", lw=1.8)
    ax.plot([x - 0.45, x + 0.45], [y + 0.25, y + 0.25], color="#222", lw=1.8)
    ax.plot([x, x - 0.4], [y - 0.25, y - 0.9], color="#222", lw=1.8)
    ax.plot([x, x + 0.4], [y - 0.25, y - 0.9], color="#222", lw=1.8)
    ax.text(x, y - 1.25, name, ha="center", va="center", fontsize=13, fontweight="bold")

def link(a, b):
    ax.plot([a[0], b[0]], [a[1], b[1]], color="#444", lw=1.1, zorder=0)

def dashed(a, b, label, dx=0.55):
    ax.annotate("", xy=b, xytext=a,
                arrowprops=dict(arrowstyle="->", ls="--", color="#555", lw=1.2))
    ax.text((a[0]+b[0])/2 + dx, (a[1]+b[1])/2, label, fontsize=9.5,
            style="italic", ha="center", va="center", color="#333")

L = 4.9; M = 8.0; R = 11.1
left_rows = ["Add Customer", "Take Order", "Generate Bill", "Process Payment",
             "Cancel Unpaid Order", "Update / Delete Customer", "Search Record", "Display Records"]
ys = [9.05 - 1.1 * i for i in range(len(left_rows))]
left = {n: uc(L, y, n) for n, y in zip(left_rows, ys)}
valid = uc(M, left["Process Payment"][1], "Validate Payment\nDetails", w=2.6, h=0.9)

right_rows = ["Add Menu Item", "Update Menu Item", "Delete Menu Item",
              "Generate Sales Report", "Save / Load Data"]
rys = [8.4 - 1.1 * i for i in range(len(right_rows))]
right = {n: uc(R, y, n) for n, y in zip(right_rows, rys)}
persist = uc(R, rys[-1] - 1.3, "Persist Records\nto Files", w=2.7, h=0.9)

cashier = (1.3, 5.0); manager = (14.7, 5.4); customer = (1.3, 1.6)
actor(*cashier, "Cashier"); actor(*manager, "Manager"); actor(*customer, "Customer")

cs = (cashier[0] + 0.45, cashier[1] + 0.25)
for n, t in left.items():
    link(cs, (t[0] - 1.5, t[1]))
ms = (manager[0] - 0.45, manager[1] + 0.25)
for n, t in right.items():
    link(ms, (t[0] + 1.5, t[1]))
cu = (customer[0] + 0.45, customer[1] + 0.25)
link(cu, (left["Process Payment"][0] - 1.5, left["Process Payment"][1] - 0.05))
link(cu, (left["Take Order"][0] - 1.5, left["Take Order"][1] - 0.05))

dashed((left["Process Payment"][0] + 1.5, left["Process Payment"][1]),
       (valid[0] - 1.3, valid[1]), "<<include>>", dx=0.0)
ax.texts[-1].set_position((6.4, left["Process Payment"][1] + 0.3))
dashed((left["Take Order"][0] + 0.7, left["Take Order"][1] - 0.4),
       (left["Generate Bill"][0] + 0.7, left["Generate Bill"][1] + 0.4), "<<include>>")
dashed((left["Generate Bill"][0] + 0.7, left["Generate Bill"][1] - 0.4),
       (left["Process Payment"][0] + 0.7, left["Process Payment"][1] + 0.4), "<<include>>")
dashed((right["Save / Load Data"][0], right["Save / Load Data"][1] - 0.41),
       (persist[0], persist[1] + 0.45), "<<include>>")

# actor generalisation: Manager is-a Cashier (hollow triangle arrow routed above the system box)
ax.plot([manager[0], manager[0]], [manager[1] + 1.05, 10.6], color="#222", lw=1.5)
ax.plot([manager[0], cashier[0]], [10.6, 10.6], color="#222", lw=1.5)
ax.annotate("", xy=(cashier[0], cashier[1] + 1.1), xytext=(cashier[0], 10.6),
            arrowprops=dict(arrowstyle="-|>", fc="white", ec="#222", lw=1.5, mutation_scale=22))
ax.text(8.0, 10.85, "Manager inherits all Cashier use cases (actor generalization)",
        ha="center", fontsize=11, style="italic")

ax.text(8.0, 0.25, "Figure 1: Use Case Diagram - Restaurant Billing System   (Jenil Nagpara, IU2541230046)",
        ha="center", fontsize=11, style="italic")
plt.tight_layout()
plt.savefig("Use_Case_Diagram.png", dpi=170)
plt.close()

# ============================== CLASS DIAGRAM ===============================
def cls(name, attrs, ops, abstract=False, fill="#FFF9E5"):
    nm = f"<I>{name}</I>" if abstract else f"<B>{name}</B>"
    def rows(lst):
        if not lst: return '<TR><TD ALIGN="LEFT"> </TD></TR>'
        return "".join(f'<TR><TD ALIGN="LEFT">{html.escape(r)}</TD></TR>' for r in lst)
    return (f'<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" BGCOLOR="{fill}">'
            f'<TR><TD BGCOLOR="#D6E4F5"><FONT POINT-SIZE="15">{nm}</FONT></TD></TR>'
            f'<HR/>{rows(attrs)}<HR/>{rows(ops)}</TABLE>>')

g = []
g.append('digraph G { rankdir=TB; nodesep=0.45; ranksep=0.8; splines=true; dpi=130;')
g.append('node [shape=plain fontname="Liberation Serif" fontsize=12]; edge [fontname="Liberation Serif" fontsize=11];')
g.append('labelloc=b; fontname="Liberation Serif"; fontsize=14; '
         'label="Figure 2: Class Diagram - Restaurant Billing System (Jenil Nagpara, IU2541230046)";')

g.append('RS [label=' + cls("RestaurantSystem",
  ["- menu : MenuItem**", "- customers : Customer*", "- orders : Order*", "- bills : Bill*",
   "- payments : Payment**", "- menuCount, customerCount, orderCount : int",
   "- billCount, paymentCount : int", "- nextItemId, nextOrderId, nextBillId : int",
   "- fileManager : FileManager"],
  ["+ startup() / shutdown() : void", "+ addRecord() : void", "+ displayRecords() : void",
   "+ searchRecord() : void", "+ updateRecord() : void", "+ deleteRecord() : void",
   "+ mainTransaction() : void", "+ generateReport() : void", "+ saveLoadMenu() : void",
   "- takeNewOrder() : int", "- generateBillForOrder(i : int) : int",
   "- processPaymentForBill(i : int) : void", "- pushMenuItem(p : MenuItem*) : void"],
  fill="#E8F5E9") + '];')

g.append('FM [label=' + cls("FileManager",
  ["- dataDir : string"],
  ["+ FileManager(dir : string)", "+ save(sys : RestaurantSystem&) : void",
   "+ load(sys : RestaurantSystem&) : int", "+ dataExists() : bool"], fill="#FDEDEC") + '];')

g.append('MI [label=' + cls("MenuItem",
  ["# itemId : int", "# name : string", "# price : double"],
  ["+ MenuItem()", "+ MenuItem(id, name, price)", "+ ~MenuItem() {virtual}",
   "+ setName(n : string) : void", "+ setPrice(p : double) : void",
   "+ getCategory() : string {abstract}", "+ getExtraInfo() : string {abstract}",
   "+ toFileString() : string {abstract}", "+ display() : void {virtual}"], abstract=True) + '];')
g.append('FI [label=' + cls("FoodItem", ["- vegetarian : bool"],
  ["+ FoodItem()", "+ FoodItem(id, name, price, veg)", "+ getCategory() : string",
   "+ getExtraInfo() : string", "+ toFileString() : string"]) + '];')
g.append('BI [label=' + cls("BeverageItem", ["- sizeMl : int"],
  ["+ BeverageItem()", "+ BeverageItem(id, name, price, ml)", "+ getCategory() : string",
   "+ getExtraInfo() : string", "+ toFileString() : string"]) + '];')

g.append('CU [label=' + cls("Customer",
  ["- customerId : int", "- name : string", "- phone : string"],
  ["+ Customer()", "+ Customer(id, name, phone)", "+ setName(n : string) : void",
   "+ setPhone(p : string) : void", "+ display() : void", "+ toFileString() : string"]) + '];')

g.append('OR [label=' + cls("Order",
  ["- orderId : int", "- customerId : int", "- itemIds : int*", "- quantities : int*",
   "- unitPrices : double*", "- itemCount, capacity : int", "- total : double",
   "- billed : bool", "- dateTime : string"],
  ["+ Order()", "+ Order(oid, cid)", "+ Order(const Order&)", "+ operator=(const Order&)",
   "+ ~Order()", "+ addItem(id, qty, price) : void", "+ calculateTotal() : double",
   "+ display() : void", "- grow() : void"]) + '];')

g.append('BL [label=' + cls("Bill",
  ["- billId : int", "- orderId : int", "- subtotal : double", "- tax : double",
   "- total : double", "- paid : bool", "- dateTime : string", "+ TAX_RATE : double = 0.05"],
  ["+ Bill()", "+ Bill(bid, oid, subtotal)", "+ calculateTotal() : void",
   "+ printBill(name, lines) : void", "+ markPaid() : void", "+ display() : void"]) + '];')

g.append('PY [label=' + cls("Payment",
  ["# paymentId : int", "# billId : int", "# mode : string", "# amount : double",
   "# processed : bool", "# dateTime : string"],
  ["+ Payment()", "+ Payment(pid, bid, mode, amt)", "+ ~Payment() {virtual}",
   "+ processPayment() : bool {abstract}", "+ getDetails() : string {abstract}",
   "+ toFileString() : string {abstract}", "+ display() : void {virtual}"], abstract=True) + '];')
g.append('CP [label=' + cls("CashPayment", ["- tendered : double", "- change : double"],
  ["+ CashPayment(pid, bid, amt, tendered)", "+ processPayment() : bool", "+ getDetails() : string"]) + '];')
g.append('DP [label=' + cls("CardPayment", ["- cardNumber : string", "- last4 : string"],
  ["+ CardPayment(pid, bid, amt, cardNo)", "+ processPayment() : bool", "+ getDetails() : string"]) + '];')
g.append('UP [label=' + cls("UpiPayment", ["- upiId : string"],
  ["+ UpiPayment(pid, bid, amt, id)", "+ processPayment() : bool", "+ getDetails() : string"]) + '];')

g.append('EX [label=' + cls("BillingException",
  [], ["+ BillingException(msg : string)"],
  fill="#F3E5F5") + '];')
g.append('EX2 [label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="3" BGCOLOR="#F3E5F5">'
         '<TR><TD>ValidationException<BR/>NotFoundException<BR/>PaymentException<BR/>'
         'FileException<BR/>InputClosedException</TD></TR></TABLE>>];')

# ---- layout rows (compact, near-square) ----
g.append('{rank=same; FM -> RS [style=invis]; RS -> EX [style=invis]}')
g.append('{rank=same; CU -> OR [dir=back arrowtail=vee label="  placed by\\n  (customerId)" taillabel="1" headlabel="*" labelfontsize=10]; '
         'OR -> BL [dir=back arrowtail=vee label="  bills\\n  (orderId)" taillabel="1" headlabel="1"]; '
         'BL -> PY [dir=back arrowtail=vee label="  settles\\n  (billId)" taillabel="1" headlabel="0..1"]; '
         'PY -> EX2 [style=invis]}')
g.append('{rank=same; MI -> CP [style=invis]; CP -> DP [style=invis]; DP -> UP [style=invis]}')
g.append('{rank=same; FI -> BI [style=invis]}')
# composition: RestaurantSystem owns the entity arrays (filled diamond on RestaurantSystem)
for tgt in ("CU", "OR", "BL", "PY", "MI"):
    g.append(f'RS -> {tgt} [dir=back arrowtail=diamond arrowsize=1.3 taillabel="0..*" labeldistance=2.2];')
g.append('RS -> FM [arrowhead=vee style=dashed constraint=false label="  uses / friend"];')
g.append('RS -> EX [arrowhead=vee style=dashed constraint=false label="  throws / catches"];')
# inheritance (hollow triangle, child -> parent)
for child, parent in (("FI", "MI"), ("BI", "MI"), ("CP", "PY"), ("DP", "PY"), ("UP", "PY"), ("EX2", "EX")):
    g.append(f'{child} -> {parent} [arrowhead=empty arrowsize=1.4];')
g.append('}')
open("class_diagram.dot", "w").write("\n".join(g))
subprocess.run(["dot", "-Tpng", "class_diagram.dot", "-o", "Class_Diagram.png"], check=True)
print("done")
