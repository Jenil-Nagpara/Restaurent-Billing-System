/*
 * RestaurantSystem.h
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 *
 * The "System" class of the blueprint. It owns all records in DYNAMIC arrays,
 * implements every main-menu option and talks to FileManager for persistence.
 *
 *   menu      : MenuItem**  (array of base-class pointers -> polymorphism)
 *   customers : Customer*   (new Customer[capacity])
 *   orders    : Order*      (new Order[capacity])
 *   bills     : Bill*       (new Bill[capacity])
 *   payments  : Payment**   (array of base-class pointers -> polymorphism)
 */
#ifndef RESTAURANT_SYSTEM_H
#define RESTAURANT_SYSTEM_H

#include <string>
#include "MenuItem.h"
#include "Customer.h"
#include "Order.h"
#include "Bill.h"
#include "Payment.h"
#include "FileManager.h"

class RestaurantSystem {
    // ----- dynamic storage -----
    MenuItem** menu;       int menuCount;      int menuCap;
    Customer*  customers;  int customerCount;  int customerCap;
    Order*     orders;     int orderCount;     int orderCap;
    Bill*      bills;      int billCount;      int billCap;
    Payment**  payments;   int paymentCount;   int paymentCap;

    // ----- auto-numbering -----
    int nextItemId, nextCustomerId, nextOrderId, nextBillId, nextPaymentId;

    FileManager fileManager;

    friend class FileManager;      // FileManager reads / fills the arrays directly

    // ----- low level helpers (store a record, growing the array when full) -----
    void pushMenuItem(MenuItem* item);          // takes OWNERSHIP of the pointer
    void pushCustomer(const Customer& c);
    void pushOrder(const Order& o);
    void pushBill(const Bill& b);
    void pushPayment(Payment* p);               // takes OWNERSHIP of the pointer
    void clearAll();                            // delete / delete[] everything
    void seedSampleMenu();

    // ----- lookups (return index or -1) -----
    int findMenuIndex(int id) const;
    int findMenuByName(const std::string& name) const;
    int findCustomerIndex(int id) const;
    int findOrderIndex(int id) const;
    int findBillIndex(int id) const;
    int findBillByOrder(int orderId) const;
    std::string customerNameOf(int customerId) const;
    std::string itemNameOf(int itemId) const;
    std::string buildItemLines(const Order& o) const;
    bool hasPendingWork(int customerId) const;

    // ----- sub-operations -----
    void addMenuItem();
    void addCustomer();
    void displayMenu() const;
    void displayCustomers() const;
    void displayOrders() const;
    void displayBills() const;
    void displayPayments() const;
    void printOrderDetails(const Order& o) const;
    void updateMenuItem();
    void updateCustomer();
    void deleteMenuItem();
    void deleteCustomer();
    void deleteOrder();

    int  takeNewOrder();                        // returns index of new order or -1
    int  generateBillForOrder(int orderIndex);  // returns index of new bill
    void printBillAt(int billIndex) const;
    void processPaymentForBill(int billIndex);

public:
    explicit RestaurantSystem(const std::string& dataDir = "Data");
    ~RestaurantSystem();
    RestaurantSystem(const RestaurantSystem&) = delete;              // owns raw memory
    RestaurantSystem& operator=(const RestaurantSystem&) = delete;

    void startup();            // load saved data (or seed sample menu on first run)
    void shutdown();           // save everything

    // ----- main-menu operations -----
    void addRecord();
    void displayRecords() const;
    void searchRecord() const;
    void updateRecord();
    void deleteRecord();
    void mainTransaction();
    void generateReport() const;
    void saveLoadMenu();
};

#endif
