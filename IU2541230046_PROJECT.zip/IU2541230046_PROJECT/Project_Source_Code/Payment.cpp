/*
 * Payment.cpp
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 */
#include "Payment.h"
#include "BillingException.h"
#include "InputHelper.h"

#include <iostream>
#include <iomanip>
#include <sstream>
#include <cctype>

// ============================== Payment =====================================
Payment::Payment()
    : paymentId(0), billId(0), mode(""), amount(0.0), processed(false), dateTime("") {}

Payment::Payment(int pid, int bid, const std::string& payMode, double amt)
    : paymentId(pid), billId(bid), mode(payMode), amount(amt), processed(false), dateTime("") {}

Payment::~Payment() {
#ifdef DEBUG_TRACE
    std::cerr << "[trace] ~Payment " << paymentId << "\n";
#endif
}

void Payment::printHeader() {
    std::cout << "+--------+--------+--------+------------+------------------+--------------------------------+\n"
              << "| Pay ID | Bill   | Mode   | Amt (Rs)   | Date / Time      | Details                        |\n"
              << "+--------+--------+--------+------------+------------------+--------------------------------+\n";
}

void Payment::display() const {
    std::cout << "| " << std::left << std::setw(6) << paymentId
              << " | " << std::setw(6) << billId
              << " | " << std::setw(6) << mode
              << " | " << std::right << std::fixed << std::setprecision(2) << std::setw(10) << amount
              << " | " << std::left << std::setw(16) << dateTime
              << " | " << std::setw(30) << InputHelper::truncate(getDetails(), 30) << " |\n";
}

// ============================ CashPayment ===================================
CashPayment::CashPayment() : Payment(), tendered(0.0), change(0.0) { mode = "Cash"; }

CashPayment::CashPayment(int pid, int bid, double amt, double cashTendered)
    : Payment(pid, bid, "Cash", amt), tendered(cashTendered), change(0.0) {}

CashPayment::CashPayment(int pid, int bid, double amt, const std::string& dt,
                         double cashTendered, double changeGiven)
    : Payment(pid, bid, "Cash", amt), tendered(cashTendered), change(changeGiven) {
    dateTime = dt;  processed = true;
}

CashPayment::~CashPayment() {}

bool CashPayment::processPayment() {
    if (tendered + 0.0001 < amount) {
        std::ostringstream os;
        os << std::fixed << std::setprecision(2)
           << "Cash tendered (Rs. " << tendered << ") is less than amount due (Rs. " << amount << ").";
        throw PaymentException(os.str());
    }
    change = InputHelper::round2(tendered - amount);
    processed = true;
    dateTime = InputHelper::nowString();
    return true;
}

std::string CashPayment::getDetails() const {
    std::ostringstream os;
    os << std::fixed << std::setprecision(2) << "Tendered " << tendered << ", Change " << change;
    return os.str();
}

std::string CashPayment::toFileString() const {
    std::ostringstream os;
    os << "C|" << paymentId << "|" << billId << "|" << std::fixed << std::setprecision(2)
       << amount << "|" << dateTime << "|" << tendered << "|" << change;
    return os.str();
}

// ============================ CardPayment ===================================
CardPayment::CardPayment() : Payment(), cardNumber(""), last4("") { mode = "Card"; }

CardPayment::CardPayment(int pid, int bid, double amt, const std::string& cardNo)
    : Payment(pid, bid, "Card", amt), cardNumber(cardNo), last4("") {}

CardPayment::CardPayment(int pid, int bid, double amt, const std::string& dt,
                         const std::string& lastFour)
    : Payment(pid, bid, "Card", amt), cardNumber(""), last4(lastFour) {
    dateTime = dt;  processed = true;
}

CardPayment::~CardPayment() {}

bool CardPayment::processPayment() {
    std::string digits;
    for (unsigned char c : cardNumber) {
        if (std::isdigit(c)) digits += static_cast<char>(c);
        else if (c != ' ' && c != '-')
            throw PaymentException("Card number may contain digits only.");
    }
    if (digits.size() != 16)
        throw PaymentException("Card number must contain exactly 16 digits.");
    last4 = digits.substr(12);
    cardNumber.clear();                    // never keep the full card number
    processed = true;
    dateTime = InputHelper::nowString();
    return true;
}

std::string CardPayment::getDetails() const { return "Card ending " + last4; }

std::string CardPayment::toFileString() const {
    std::ostringstream os;
    os << "D|" << paymentId << "|" << billId << "|" << std::fixed << std::setprecision(2)
       << amount << "|" << dateTime << "|" << last4;
    return os.str();
}

// ============================= UpiPayment ===================================
UpiPayment::UpiPayment() : Payment(), upiId("") { mode = "UPI"; }

UpiPayment::UpiPayment(int pid, int bid, double amt, const std::string& id)
    : Payment(pid, bid, "UPI", amt), upiId(id) {}

UpiPayment::UpiPayment(int pid, int bid, double amt, const std::string& dt,
                       const std::string& id)
    : Payment(pid, bid, "UPI", amt), upiId(id) {
    dateTime = dt;  processed = true;
}

UpiPayment::~UpiPayment() {}

bool UpiPayment::processPayment() {
    size_t at = upiId.find('@');
    bool ok = upiId.size() >= 5 && upiId.size() <= 40 &&
              at != std::string::npos && at > 0 && at < upiId.size() - 1 &&
              upiId.find('@', at + 1) == std::string::npos;
    for (unsigned char c : upiId)
        if (std::isspace(c) || c == '|') ok = false;
    if (!ok) throw PaymentException("Invalid UPI ID. Expected format: name@bank");
    processed = true;
    dateTime = InputHelper::nowString();
    return true;
}

std::string UpiPayment::getDetails() const { return "UPI " + upiId; }

std::string UpiPayment::toFileString() const {
    std::ostringstream os;
    os << "U|" << paymentId << "|" << billId << "|" << std::fixed << std::setprecision(2)
       << amount << "|" << dateTime << "|" << upiId;
    return os.str();
}
