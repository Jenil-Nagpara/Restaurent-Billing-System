#!/usr/bin/env python3
# Screenshot generator - runs the REAL program in a pseudo-terminal and renders the console to PNG
# Restaurant Billing System | Jenil Nagpara | IU2541230046
import os, pty, select, time, re, shutil, subprocess, sys
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC  = os.path.join(ROOT, "Project_Source_Code")
OUT  = os.path.dirname(os.path.abspath(__file__))
RUN  = "/tmp/shotrun"
shutil.rmtree(RUN, ignore_errors=True); os.makedirs(RUN)
shutil.copy(os.path.join(SRC, "RestaurantBilling"), RUN)

def capture(inputs, delay=0.07):
    """returns list of (text, kind) kind in {'out','in'}"""
    pid, fd = pty.fork()
    if pid == 0:
        os.chdir(RUN); os.execv("./RestaurantBilling", ["./RestaurantBilling"]); sys.exit(1)
    def drain(t):
        buf = b""; end = time.time() + t
        while time.time() < end:
            r, _, _ = select.select([fd], [], [], 0.02)
            if r:
                try: d = os.read(fd, 65536)
                except OSError: break
                if not d: break
                buf += d; end = time.time() + t
        return buf.decode("utf-8", "replace").replace("\r", "")
    segs = [(drain(0.4), "out")]
    for line in inputs:
        os.write(fd, (line + "\n").encode())
        chunk = drain(delay)
        if chunk.startswith(line + "\n"):
            segs.append((line + "\n", "in")); chunk = chunk[len(line) + 1:]
        segs.append((chunk, "out"))
    segs.append((drain(0.4), "out"))
    try: os.waitpid(pid, 0)
    except Exception: pass
    return segs

def to_lines(segs):
    """split into lines of [(char, kind)]"""
    lines, cur = [], []
    for text, kind in segs:
        for ch in text:
            if ch == "\n": lines.append(cur); cur = []
            else: cur.append((ch, kind))
    if cur: lines.append(cur)
    return lines

def text_of(l): return "".join(c for c, _ in l)

def cut(lines, start, end, start_occ=1, end_extra=0):
    idx = [i for i, l in enumerate(lines) if re.search(start, text_of(l))]
    s = idx[start_occ - 1]
    e = next(i for i in range(s, len(lines)) if re.search(end, text_of(lines[i])))
    return lines[s: e + 1 + end_extra]

FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 16)
CW = FONT.getlength("M")
COL = {"def": (204, 204, 204), "in": (255, 214, 102), "ok": (95, 215, 95),
       "err": (255, 95, 95), "info": (95, 190, 255), "dim": (140, 140, 140)}

def render(lines, name, title="Terminal - RestaurantBilling"):
    cols = max(len(l) for l in lines) if lines else 40
    w = int(max(cols, 70) * CW) + 44
    h = len(lines) * 21 + 78
    img = Image.new("RGB", (w, h), (18, 18, 18))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, w, 34], fill=(45, 45, 48))
    for i, c in enumerate(((255, 95, 86), (255, 189, 46), (39, 201, 63))):
        d.ellipse([14 + i * 22, 11, 26 + i * 22, 23], fill=c)
    d.text((w // 2 - len(title) * 4, 8), title, font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14), fill=(210, 210, 210))
    y = 48
    for l in lines:
        t = text_of(l)
        flag = None; flag_at = len(t)
        for tok, c in (("[OK]", "ok"), ("[ERROR]", "err"), ("[!]", "err"), ("[UNEXPECTED", "err"), ("[INFO]", "info")):
            p = t.find(tok)
            if p >= 0 and p < flag_at: flag, flag_at = c, p
        x = 22
        for i, (ch, kind) in enumerate(l):
            colr = COL["in"] if kind == "in" else (COL[flag] if flag and i >= flag_at else COL["def"])
            d.text((x, y), ch, font=FONT, fill=colr)
            x += CW
        y += 21
    path = os.path.join(OUT, name + ".png")
    img.save(path)
    print("saved", name, img.size)

def shell_lines(prompt_cmds):
    out = []
    for cmd, text in prompt_cmds:
        out.append([(c, "in") for c in "$ " + cmd])
        for ln in text.split("\n"):
            out.append([(c, "out") for c in ln])
    return out

# ----------------------------------------------------------------- sessions
A = to_lines(capture(["2", "1", "9"]))                                      # first run + display menu
render(A[:52], "01_Startup_Main_Menu_and_Display_Menu")

B = to_lines(capture(["1", "1", "1", "Butter Naan", "-5", "abc", "75", "y",
                      "1", "2", "Jenil Nagpara", "12345", "9876543210",
                      "1", "2", "Aarav Shah", "9123456780",
                      "1", "2", "Riya Patel", "9988776655", "9"]))
render(cut(B, r"--- ADD RECORD", r"Menu item added", 1), "02_Add_Menu_Item_With_Validation")
render(cut(B, r"--- ADD RECORD", r"Customer added with ID 1001", 2), "03_Add_Customer_With_Validation")

C = to_lines(capture(["3", "2", "biryani", "3", "3", "9999", "4", "1", "101", "2", "250",
                      "4", "1", "999", "3", "1", "101", "9"]))
render(cut(C, r"--- SEARCH RECORD", r"record\(s\) found", 1), "04_Search_Menu_Item_By_Name")
render(cut(C, r"--- SEARCH RECORD", r"No customer with ID 9999", 2), "05_Search_Not_Found_Exception")
render(cut(C, r"--- UPDATE RECORD", r"Price updated", 1), "06_Update_Menu_Item_Price")

D = to_lines(capture(["5", "1", "113", "y", "9"]))
render(cut(D, r"--- DELETE RECORD", r"Menu item deleted", 1), "07_Delete_Menu_Item")

E = to_lines(capture(["6", "1", "1001", "101", "2", "110", "1", "0", "y", "1", "1000", "9"]))
render(cut(E, r"--- MAIN TRANSACTION", r"Thank you! Please visit again", 1, 2), "08_Main_Transaction_Order_And_Bill")
render(cut(E, r"Proceed to payment", r"Details    :", 1), "09_Cash_Payment_Success")

F = to_lines(capture(["6", "1", "1002", "105", "4", "0", "y", "1", "100", "y", "200", "9"]))
render(cut(F, r"Proceed to payment", r"Change", 1), "10_Cash_Payment_Exception_And_Retry")

G = to_lines(capture(["6", "1", "1001", "103", "1", "0", "y", "2", "12345", "y", "4111 1111 1111 1234", "9"]))
render(cut(G, r"Proceed to payment", r"Card ending", 1), "11_Card_Payment_Validation")

H = to_lines(capture(["6", "1", "1003", "109", "2", "0", "y", "3", "badid", "y", "jenil@okbank", "9"]))
render(cut(H, r"Proceed to payment", r"UPI jenil", 1), "12_UPI_Payment_Validation")

I = to_lines(capture(["7", "9"]))
render(cut(I, r"=+ SALES REPORT", r"^=+$", 1, 0)[:40] if False else
       cut(I, r"=+ SALES REPORT", r"Top customer", 1, 1), "13_Sales_Report")

J = to_lines(capture(["5", "3", "5001", "9"]))                              # rule check
K = to_lines(capture(["2", "6", "9"]))                                      # restart: persistence
render(K[:9], "14_Restart_Data_Loaded_From_File")
render(cut(K, r"\[CUSTOMERS\]", r"^\+-+\+-+\+-+\+-+\+-+\+-+\+$", 1) if False else
       cut(K, r"\[CUSTOMERS\]", r"\[PAYMENTS\]", 1, 8), "15_Persistence_Customers_Orders_Bills_Payments")

# data files + build/test shells
files = subprocess.run("cd %s && ls -l Data && echo && for f in customers orders bills payments; do echo \"--- Data/$f.txt\"; cat Data/$f.txt; done" % RUN,
                       shell=True, capture_output=True, text=True).stdout.rstrip("\n")
render(shell_lines([("ls -l Data ; cat Data/*.txt", files)]), "16_Data_Files_Created", "Terminal - Data folder")

build = subprocess.run("cd %s && g++ -std=c++17 -Wall -Wextra -O2 main.cpp InputHelper.cpp MenuItem.cpp Customer.cpp Order.cpp Bill.cpp Payment.cpp FileManager.cpp RestaurantSystem.cpp -o RestaurantBilling && echo 'Build successful - 0 errors, 0 warnings' && ls -l RestaurantBilling" % SRC,
                       shell=True, capture_output=True, text=True)
tests = subprocess.run("cd %s/tests && python3 run_tests.py ../RestaurantBilling" % SRC, shell=True, capture_output=True, text=True).stdout.rstrip("\n")
render(shell_lines([("g++ -std=c++17 -Wall -Wextra -O2 *.cpp -o RestaurantBilling", build.stdout.rstrip("\n") + build.stderr.rstrip("\n")),
                    ("python3 tests/run_tests.py", tests)]), "17_Build_And_Automated_Test_Results", "Terminal - build and tests")
