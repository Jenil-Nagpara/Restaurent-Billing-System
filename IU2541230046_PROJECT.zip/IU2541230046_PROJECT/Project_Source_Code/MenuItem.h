/*
 * MenuItem.h
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 *
 * MenuItem is an ABSTRACT base class. FoodItem and BeverageItem inherit from
 * it and override the virtual functions (Inheritance + Runtime Polymorphism).
 */
#ifndef MENU_ITEM_H
#define MENU_ITEM_H

#include <string>

class MenuItem {
protected:
    int         itemId;
    std::string name;
    double      price;

public:
    static constexpr double MAX_PRICE = 10000.0;

    MenuItem();                                              // default constructor
    MenuItem(int id, const std::string& itemName, double itemPrice);  // parameterized
    virtual ~MenuItem();                                     // virtual destructor

    // getters / setters (Encapsulation)
    int         getItemId() const { return itemId; }
    std::string getName()   const { return name; }
    double      getPrice()  const { return price; }
    void        setName(const std::string& newName);
    void        setPrice(double newPrice);

    // polymorphic interface
    virtual std::string getCategory()  const = 0;   // "Food" / "Beverage"
    virtual std::string getExtraInfo() const = 0;   // "Veg" / "300 ml"
    virtual std::string toFileString() const = 0;   // one line for the data file
    virtual void        display() const;            // one table row

    static void printHeader();
};

// ---------------------------------------------------------------------------
class FoodItem : public MenuItem {
    bool vegetarian;
public:
    FoodItem();
    FoodItem(int id, const std::string& itemName, double itemPrice, bool veg);
    ~FoodItem() override;

    bool        isVegetarian() const { return vegetarian; }
    std::string getCategory()  const override { return "Food"; }
    std::string getExtraInfo() const override { return vegetarian ? "Veg" : "Non-Veg"; }
    std::string toFileString() const override;
};

// ---------------------------------------------------------------------------
class BeverageItem : public MenuItem {
    int sizeMl;
public:
    BeverageItem();
    BeverageItem(int id, const std::string& itemName, double itemPrice, int ml);
    ~BeverageItem() override;

    int         getSizeMl() const { return sizeMl; }
    std::string getCategory()  const override { return "Beverage"; }
    std::string getExtraInfo() const override { return std::to_string(sizeMl) + " ml"; }
    std::string toFileString() const override;
};

#endif
