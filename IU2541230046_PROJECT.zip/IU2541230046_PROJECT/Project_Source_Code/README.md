# Restaurant Billing System (C++ OOP Console Project)

| | |
|---|---|
| **Student** | Jenil Nagpara |
| **Enrollment No.** | IU2541230046 |
| **Project code** | CPP27 - C++ Guided Project (Semester 3) |

A console-based billing application for a small restaurant. It manages the menu and customers,
takes orders, generates GST bills, accepts **Cash / Card / UPI** payments and stores everything in
text files so the data is still there when the program is reopened.

## Features
- Add / Display / Search / Update / Delete records (menu items and customers)
- Main transaction: **Order -> Bill (5 % GST) -> Payment** (cash with change, card, UPI)
- Sales report: revenue, GST, pending amount, revenue by payment mode, item-wise sales, best seller, top customer
- File persistence (`Data/*.txt`) - loaded at start-up, saved on exit or from menu option 8
- Input validation + custom exception classes (the program never crashes on bad input)

## C++ concepts demonstrated
Classes & objects - Encapsulation - Default + parameterized constructors - Destructors (virtual) -
Inheritance (`MenuItem` -> `FoodItem`/`BeverageItem`, `Payment` -> `CashPayment`/`CardPayment`/`UpiPayment`) -
Runtime polymorphism - Dynamic memory (`new[]` / `delete[]`, Rule of Three in `Order`) -
File handling - Validation - Exception handling

## Build
Requires a C++17 compiler (g++ / MinGW).

**Linux / macOS**
```
make
./RestaurantBilling
```

**Windows (MinGW)** - double-click `build.bat` or run:
```
g++ -std=c++17 -Wall -Wextra -O2 main.cpp InputHelper.cpp MenuItem.cpp Customer.cpp Order.cpp Bill.cpp Payment.cpp FileManager.cpp RestaurantSystem.cpp -o RestaurantBilling.exe
RestaurantBilling.exe
```
Run the program from this folder so it finds the `Data/` directory (an optional argument selects another folder:
`RestaurantBilling my_data_folder`).

## Using the program
```
1. Add Record            5. Delete Record
2. Display Records       6. Main Transaction / Process (Order -> Bill -> Payment)
3. Search Record         7. Report
4. Update Record         8. Save / Load
                         9. Exit (saves automatically)
```
Quick demo: option **6 -> 1** (complete billing flow) -> enter customer ID `1001` -> add items -> bill is printed -> pay.
On the very first run (no `Data/menu.txt`) a sample menu of 12 items is created automatically.
The shipped `Data/` folder already contains demo records so you can see persistence immediately.

## Project structure
```
main.cpp                    menu loop only (creates RestaurantSystem and calls its functions)
RestaurantSystem.h/.cpp     controller: owns the dynamic arrays, implements every menu option
MenuItem.h/.cpp             abstract MenuItem + FoodItem + BeverageItem
Customer.h/.cpp             Customer
Order.h/.cpp                Order (dynamic arrays, Rule of Three)
Bill.h/.cpp                 Bill (GST, invoice printing)
Payment.h/.cpp              abstract Payment + CashPayment + CardPayment + UpiPayment
FileManager.h/.cpp          save() / load() of all data files
InputHelper.h/.cpp          validated console input + string helpers
BillingException.h          custom exception hierarchy
Data/                       menu.txt customers.txt orders.txt bills.txt payments.txt
tests/run_tests.py          automated test cases (T01-T17)
Makefile, build.bat         build scripts
```

## Testing
```
python3 tests/run_tests.py ./RestaurantBilling      # 17 automated test cases (T01-T15 required + 2 bonus)
```
The same suite was also run with `g++ -fsanitize=address,undefined` (AddressSanitizer + LeakSanitizer):
no memory errors and no leaks were reported. Compile with `-DDEBUG_TRACE` to print a message from every destructor.

## Publishing to GitHub
```
git init
git add .
git commit -m "Restaurant Billing System - Jenil Nagpara IU2541230046"
git branch -M main
git remote add origin https://github.com/<your-username>/<repository-name>.git
git push -u origin main
```
