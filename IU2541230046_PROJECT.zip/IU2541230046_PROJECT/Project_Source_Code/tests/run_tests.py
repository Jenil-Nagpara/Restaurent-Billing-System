#!/usr/bin/env python3
"""
Automated test runner - Restaurant Billing System
Student : Jenil Nagpara   Enrollment No.: IU2541230046

Runs the program once per test case (a fresh process each time, so every test
after the first also proves that data persisted in the Data files).

Usage:  python3 run_tests.py [path-to-executable]
"""
import subprocess, sys, shutil, os, json

EXE = sys.argv[1] if len(sys.argv) > 1 else os.path.join("..", "RestaurantBilling")
DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_test_data")

# (id, operation, input summary, stdin, [expected substrings], expected-text)
TESTS = [
 ("T01", "Add food item (valid)", "Food, 'Butter Naan', Rs.55, veg",
  "1\n1\n1\nButter Naan\n55\ny\n9\n",
  ["Menu item added with ID 113"], "Item saved with next ID 113"),
 ("T02", "Add beverage - invalid prices", "Price: -5, abc, 0, then 85",
  "1\n1\n2\nBanana Shake\n-5\nabc\n0\n85\n300\n9\n",
  ["Invalid input. Enter a number between", "Menu item added with ID 114"],
  "Bad prices rejected and re-asked; valid price accepted"),
 ("T03", "Add duplicate menu item", "Name: 'paneer tikka' (already exists)",
  "1\n1\n1\npaneer tikka\n9\n",
  ["[ERROR] A menu item named 'paneer tikka' already exists."],
  "ValidationException raised; duplicate rejected"),
 ("T04", "Add customer (valid)", "Jenil Nagpara, 9876543210",
  "1\n2\nJenil Nagpara\n9876543210\n9\n",
  ["Customer added with ID 1001"], "Customer saved with ID 1001"),
 ("T05", "Add customer - invalid phone", "Phone: 12345, 5123456789, then 9123456780",
  "1\n2\nAarav Shah\n12345\n5123456789\n9123456780\n9\n",
  ["Phone must be exactly 10 digits", "Customer added with ID 1002"],
  "Invalid phones rejected; valid phone accepted"),
 ("T06", "Add customer - duplicate phone", "Phone 9876543210 again",
  "1\n2\nRiya Patel\n9876543210\n9\n",
  ["[ERROR] A customer with this phone number already exists (ID 1001)."],
  "Duplicate phone rejected"),
 ("T07", "Search menu item by name", "Search text: 'biryani'",
  "3\n2\nbiryani\n9\n",
  ["2 record(s) found"], "Veg Biryani and Chicken Biryani listed"),
 ("T08", "Search non-existing customer", "Customer ID 9999",
  "3\n3\n9999\n9\n",
  ["[ERROR] No customer with ID 9999."], "NotFoundException handled; back to menu"),
 ("T09", "Update menu item price", "Item 101 -> Rs.250, then search it",
  "4\n1\n101\n2\n250\n3\n1\n101\n9\n",
  ["Price updated", "250.00"], "New price saved and shown on search"),
 ("T10", "Delete menu item", "Delete item 113, then search it",
  "5\n1\n113\ny\n3\n1\n113\n9\n",
  ["Menu item deleted", "[ERROR] No menu item with ID 113."],
  "Item removed from the array and from the file"),
 ("T11", "Full billing flow - Cash", "Cust 1001: 2 x Paneer Tikka(250) + 1 x Cold Coffee(110); cash 1000",
  "6\n1\n1001\n101\n2\n110\n1\n0\ny\n1\n1000\n9\n",
  ["GST (5%) :         30.50", "GRAND TOTAL (Rs.) :        640.50", "Tendered 1000.00, Change 359.50"],
  "Subtotal 610.00, GST 30.50, Total 640.50, change 359.50"),
 ("T12", "Cash payment too low, then retry", "Order 4 x Garlic Naan; cash 100, retry, cash 200",
  "6\n1\n1002\n105\n4\n0\ny\n1\n100\ny\n200\n9\n",
  ["Payment failed: Cash tendered (Rs. 100.00) is less than amount due (Rs. 189.00).", "Change 11.00"],
  "PaymentException shown, retry accepted, change Rs. 11.00"),
 ("T13", "Card payment - invalid then valid", "Card '12345', then '4111 1111 1111 1234'",
  "6\n1\n1001\n103\n1\n0\ny\n2\n12345\ny\n4111 1111 1111 1234\n9\n",
  ["Card number must contain exactly 16 digits", "Card ending 1234"],
  "Short card rejected; valid card accepted and masked"),
 ("T14", "UPI payment - invalid then valid", "UPI 'badid', then 'jenil@okbank'",
  "6\n1\n1002\n109\n2\n0\ny\n3\nbadid\ny\njenil@okbank\n9\n",
  ["Invalid UPI ID. Expected format: name@bank", "UPI jenil@okbank"],
  "Bad UPI id rejected; valid id accepted"),
 ("T15", "Persistence - close, reopen, report", "Restart program, show report",
  "7\n9\n",
  ["Saved data loaded from", "13 menu items, 2 customers, 4 orders, 4 bills, 4 payments",
   "Total revenue (paid bills) : Rs. 1249.50"],
  "All old records reloaded; revenue Rs. 1249.50"),
 # ----- bonus tests (not in the 15 required) -----
 ("T16", "Cancel an already paid order", "Order 5001",
  "5\n3\n5001\n9\n",
  ["[ERROR] This order is already paid and cannot be cancelled."], "Refused (rule check)"),
 ("T17", "Delete customer with unpaid bill", "Create unpaid bill for 1002, delete 1002",
  "6\n1\n1002\n108\n1\n0\nn\n5\n2\n1002\n9\n",
  ["Bill kept as PENDING", "[ERROR] Customer has unpaid orders/bills and cannot be deleted."],
  "Refused (rule check)"),
]

def run(stdin):
    p = subprocess.run([EXE, DATA], input=stdin, capture_output=True, text=True, timeout=30)
    return p.stdout + p.stderr

def main():
    shutil.rmtree(DATA, ignore_errors=True)
    results, passed = [], 0
    for tid, op, inp, stdin, expects, exp_text in TESTS:
        out = run(stdin)
        ok, observed = True, []
        for e in expects:
            pos = out.find(e)
            if pos < 0:
                ok = False; observed.append("MISSING: " + e)
            else:
                end = out.find("\n", pos)
                observed.append(out[pos:end if end >= 0 else None].strip())
        if "AddressSanitizer" in out or "runtime error" in out or "LeakSanitizer" in out:
            ok = False; observed.append("SANITIZER ERROR")
        passed += ok
        results.append(dict(id=tid, operation=op, input=inp, expected=exp_text,
                            actual=" | ".join(observed), status="Pass" if ok else "Fail"))
        print(f"{tid}  {'PASS' if ok else 'FAIL'}  {op}")
    print(f"\n{passed}/{len(TESTS)} tests passed")
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "test_results.json"), "w") as f:
        json.dump(results, f, indent=2)
    shutil.rmtree(DATA, ignore_errors=True)
    sys.exit(0 if passed == len(TESTS) else 1)

if __name__ == "__main__":
    main()
