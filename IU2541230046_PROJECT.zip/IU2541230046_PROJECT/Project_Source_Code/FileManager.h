/*
 * FileManager.h
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 *
 * Responsible for ALL file handling: saving every record type to a text file
 * inside the Data/ folder and loading them back when the program starts.
 */
#ifndef FILE_MANAGER_H
#define FILE_MANAGER_H

#include <string>
#include <vector>

class RestaurantSystem;

class FileManager {
    std::string dataDir;

    std::string pathOf(const std::string& fileName) const;
    static std::vector<std::string> split(const std::string& line, char delim);

public:
    explicit FileManager(const std::string& directory = "Data");

    bool dataExists() const;                       // is there a saved menu file?
    void save(const RestaurantSystem& sys) const;  // write all 5 data files
    int  load(RestaurantSystem& sys) const;        // read all files; returns #bad lines skipped
    std::string getDirectory() const { return dataDir; }
};

#endif
