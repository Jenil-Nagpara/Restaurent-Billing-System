/*
 * MenuItem.cpp
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 */
#include "MenuItem.h"
#include "BillingException.h"
#include "InputHelper.h"

#include <iostream>
#include <iomanip>
#include <sstream>

// ============================== MenuItem ====================================
MenuItem::MenuItem() : itemId(0), name(""), price(0.0) {}

MenuItem::MenuItem(int id, const std::string& itemName, double itemPrice)
    : itemId(id), name(itemName), price(itemPrice) {}

MenuItem::~MenuItem() {
#ifdef DEBUG_TRACE
    std::cerr << "[trace] ~MenuItem " << itemId << "\n";
#endif
}

void MenuItem::setName(const std::string& newName) {
    if (!InputHelper::isValidItemName(newName))
        throw ValidationException("Invalid item name.");
    name = newName;
}

void MenuItem::setPrice(double newPrice) {
    if (newPrice <= 0 || newPrice > MAX_PRICE)
        throw ValidationException("Price must be between 0.01 and 10000.");
    price = InputHelper::round2(newPrice);
}

void MenuItem::printHeader() {
    std::cout << "+--------+--------------------------------+-----------+---------+------------+\n"
              << "| ID     | Name                           | Category  | Type    | Price (Rs) |\n"
              << "+--------+--------------------------------+-----------+---------+------------+\n";
}

void MenuItem::display() const {
    std::cout << "| " << std::left << std::setw(6) << itemId
              << " | " << std::setw(30) << InputHelper::truncate(name, 30)
              << " | " << std::setw(9)  << getCategory()      // virtual call
              << " | " << std::setw(7)  << getExtraInfo()     // virtual call
              << " | " << std::right << std::fixed << std::setprecision(2)
              << std::setw(10) << price << " |\n" << std::left;
}

// ============================== FoodItem ====================================
FoodItem::FoodItem() : MenuItem(), vegetarian(true) {}

FoodItem::FoodItem(int id, const std::string& itemName, double itemPrice, bool veg)
    : MenuItem(id, itemName, itemPrice), vegetarian(veg) {}

FoodItem::~FoodItem() {
#ifdef DEBUG_TRACE
    std::cerr << "[trace] ~FoodItem " << itemId << "\n";
#endif
}

std::string FoodItem::toFileString() const {
    std::ostringstream os;
    os << "F|" << itemId << "|" << name << "|" << std::fixed << std::setprecision(2)
       << price << "|" << (vegetarian ? 1 : 0);
    return os.str();
}

// ============================ BeverageItem ==================================
BeverageItem::BeverageItem() : MenuItem(), sizeMl(250) {}

BeverageItem::BeverageItem(int id, const std::string& itemName, double itemPrice, int ml)
    : MenuItem(id, itemName, itemPrice), sizeMl(ml) {}

BeverageItem::~BeverageItem() {
#ifdef DEBUG_TRACE
    std::cerr << "[trace] ~BeverageItem " << itemId << "\n";
#endif
}

std::string BeverageItem::toFileString() const {
    std::ostringstream os;
    os << "B|" << itemId << "|" << name << "|" << std::fixed << std::setprecision(2)
       << price << "|" << sizeMl;
    return os.str();
}
