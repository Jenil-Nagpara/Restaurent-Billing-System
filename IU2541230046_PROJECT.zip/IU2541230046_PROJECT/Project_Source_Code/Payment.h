/*
 * Payment.h
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 *
 * Payment is an ABSTRACT base class. CashPayment, CardPayment and UpiPayment
 * override processPayment() / getDetails() / toFileString().
 * RestaurantSystem keeps them as Payment* and calls processPayment()
 * through the base pointer  ->  RUNTIME POLYMORPHISM.
 */
#ifndef PAYMENT_H
#define PAYMENT_H

#include <string>

class Payment {
protected:
    int         paymentId;
    int         billId;
    std::string mode;
    double      amount;
    bool        processed;
    std::string dateTime;

public:
    Payment();
    Payment(int pid, int bid, const std::string& payMode, double amt);
    virtual ~Payment();

    // polymorphic interface
    virtual bool        processPayment() = 0;         // validates + completes the payment
    virtual std::string getDetails()  const = 0;      // mode specific details
    virtual std::string toFileString() const = 0;
    virtual void        display() const;              // one table row

    int         getPaymentId() const { return paymentId; }
    int         getBillId()    const { return billId; }
    std::string getMode()      const { return mode; }
    double      getAmount()    const { return amount; }
    bool        isProcessed()  const { return processed; }
    std::string getDateTime()  const { return dateTime; }

    static void printHeader();
};

// ---------------------------------------------------------------------------
class CashPayment : public Payment {
    double tendered;
    double change;
public:
    CashPayment();
    CashPayment(int pid, int bid, double amt, double cashTendered);
    CashPayment(int pid, int bid, double amt, const std::string& dt,
                double cashTendered, double changeGiven);          // restore from file
    ~CashPayment() override;

    double getChange() const { return change; }
    bool        processPayment() override;
    std::string getDetails()  const override;
    std::string toFileString() const override;
};

// ---------------------------------------------------------------------------
class CardPayment : public Payment {
    std::string cardNumber;     // cleared right after processing (never stored)
    std::string last4;
public:
    CardPayment();
    CardPayment(int pid, int bid, double amt, const std::string& cardNo);
    CardPayment(int pid, int bid, double amt, const std::string& dt,
                const std::string& lastFour);                      // restore from file
    ~CardPayment() override;

    bool        processPayment() override;
    std::string getDetails()  const override;
    std::string toFileString() const override;
};

// ---------------------------------------------------------------------------
class UpiPayment : public Payment {
    std::string upiId;
public:
    UpiPayment();
    UpiPayment(int pid, int bid, double amt, const std::string& id);
    UpiPayment(int pid, int bid, double amt, const std::string& dt,
               const std::string& id);                             // restore from file
    ~UpiPayment() override;

    bool        processPayment() override;
    std::string getDetails()  const override;
    std::string toFileString() const override;
};

#endif
