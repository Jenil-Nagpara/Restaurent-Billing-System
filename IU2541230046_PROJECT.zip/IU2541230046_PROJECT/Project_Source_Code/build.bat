@echo off
REM Restaurant Billing System - Jenil Nagpara (IU2541230046)
REM Builds RestaurantBilling.exe with MinGW g++ (run from this folder)
g++ -std=c++17 -Wall -Wextra -O2 main.cpp InputHelper.cpp MenuItem.cpp Customer.cpp Order.cpp Bill.cpp Payment.cpp FileManager.cpp RestaurantSystem.cpp -o RestaurantBilling.exe
if %ERRORLEVEL% EQU 0 (echo Build successful: RestaurantBilling.exe) else (echo Build FAILED)
pause
