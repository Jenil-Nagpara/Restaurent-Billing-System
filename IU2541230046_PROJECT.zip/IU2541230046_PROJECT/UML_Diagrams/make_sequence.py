# Sequence diagram generator - Restaurant Billing System | Jenil Nagpara | IU2541230046
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

plt.rcParams["font.family"] = "Liberation Serif"

def sequence(filename, title, parts, steps, width=15, row=0.62):
    """parts: list of (label, stereotype-or-None)
       steps: ('msg', a, b, text) | ('ret', a, b, text) | ('self', a, text) | ('note', text)
              ('frame', label) ... ('else', label) ... ('end',)"""
    n = len(parts)
    xs = [1.6 + i * (width - 3.2) / (n - 1) for i in range(n)]
    X = dict(zip([p[0] for p in parts], xs))
    height = 2.4 + row * (len(steps) + 1)
    fig, ax = plt.subplots(figsize=(width, height))
    ax.set_xlim(0, width); ax.set_ylim(0, height); ax.axis("off")
    top = height - 1.3
    ax.text(width / 2, height - 0.35, title, ha="center", fontsize=16, fontweight="bold")

    # figure out y of every step, remember frames
    ys, y = [], top - 0.7
    for st in steps:
        ys.append(y)
        y -= row * (1.0 if st[0] != "self" else 1.0)
    bottom = y + 0.2

    for name, stereo in parts:
        x = X[name]
        ax.add_patch(Rectangle((x - 1.0, top - 0.35), 2.0, 0.8, fc="#D6E4F5", ec="#1F4E79", lw=1.5, zorder=3))
        if stereo:
            ax.text(x, top + 0.18, stereo, ha="center", va="center", fontsize=9, style="italic", zorder=4)
            ax.text(x, top - 0.08, name, ha="center", va="center", fontsize=12, fontweight="bold", zorder=4)
        else:
            ax.text(x, top + 0.05, name, ha="center", va="center", fontsize=12, fontweight="bold", zorder=4)
        ax.plot([x, x], [top - 0.35, bottom], color="#777", lw=1, ls=(0, (5, 4)), zorder=1)

    frames = []
    for st, yy in zip(steps, ys):
        k = st[0]
        if k in ("msg", "ret"):
            _, a, b, text = st
            xa, xb = X[a], X[b]
            style = "->" if k == "msg" else "->"
            ax.annotate("", xy=(xb, yy), xytext=(xa, yy),
                        arrowprops=dict(arrowstyle="-|>" if k == "msg" else "->",
                                        color="#111", lw=1.3, ls="-" if k == "msg" else "--",
                                        mutation_scale=13), zorder=2)
            ax.text((xa + xb) / 2, yy + 0.09, text, ha="center", va="bottom", fontsize=10.5,
                    style="italic" if k == "ret" else "normal",
                    bbox=dict(fc="white", ec="none", pad=0.6), zorder=5)
        elif k == "self":
            _, a, text = st
            x = X[a]
            ax.plot([x, x + 0.6, x + 0.6], [yy + 0.12, yy + 0.12, yy - 0.12], color="#111", lw=1.3, zorder=2)
            ax.annotate("", xy=(x, yy - 0.12), xytext=(x + 0.6, yy - 0.12),
                        arrowprops=dict(arrowstyle="-|>", color="#111", lw=1.3, mutation_scale=13), zorder=2)
            ax.text(x + 0.7, yy, text, ha="left", va="center", fontsize=10.5,
                    bbox=dict(fc="white", ec="none", pad=0.6), zorder=5)
        elif k == "note":
            ax.text(width / 2, yy, st[1], ha="center", va="center", fontsize=10.5, style="italic",
                    bbox=dict(fc="#FFF4CC", ec="#B8860B", boxstyle="round,pad=0.3"), zorder=6)
        elif k in ("frame", "else", "end"):
            frames.append((k, st[1] if len(st) > 1 else "", yy))

    # draw frames (alt / loop)
    stack = []
    for k, label, yy in frames:
        if k == "frame":
            stack.append([label, yy, []])
        elif k == "else":
            stack[-1][2].append((label, yy))
        else:
            lab, y0, elses = stack.pop()
            d = len(stack); x0, x1 = 0.35 + 0.22 * d, width - 0.35 - 0.22 * d
            ax.add_patch(Rectangle((x0, yy - 0.12 + 0.1 * (1 - d) * 0 ), x1 - x0, y0 - yy + 0.3, fill=False, ec="#8B0000", lw=1.3, zorder=0))
            ax.text(x0 + 0.08, y0 + 0.08, lab, fontsize=10.5, fontweight="bold", color="#8B0000", va="center",
                    bbox=dict(fc="#FBE9E7", ec="#8B0000", pad=2), zorder=6)
            for el, ey in elses:
                ax.plot([x0, x1], [ey + 0.1, ey + 0.1], color="#8B0000", lw=1.1, ls="--", zorder=0)
                ax.text(x0 + 0.08, ey + 0.2, el, fontsize=10, color="#8B0000", va="bottom", style="italic")
    plt.tight_layout()
    plt.savefig(filename, dpi=160)
    plt.close()

# ====================== SEQUENCE DIAGRAM 1 : MAIN TRANSACTION =================
parts = [("User", "<<actor>>"), ("main()", None), ("RestaurantSystem", None),
         ("Order", None), ("Bill", None), ("Payment*", "<<abstract>>"), ("FileManager", None)]
steps = [
 ("msg", "User", "main()", "1. choose 6 (Main Transaction) -> 1 (Complete billing flow)"),
 ("msg", "main()", "RestaurantSystem", "2. mainTransaction()"),
 ("self", "RestaurantSystem", "3. takeNewOrder() : read customerId, validate"),
 ("msg", "RestaurantSystem", "Order", "4. new Order(orderId, customerId)"),
 ("frame", "loop  [until user enters 0]"),
 ("msg", "RestaurantSystem", "Order", "5. addItem(itemId, qty, unitPrice)"),
 ("self", "Order", "6. calculateTotal()"),
 ("end",),
 ("msg", "RestaurantSystem", "Order", "7. calculateTotal()  -> subtotal"),
 ("self", "RestaurantSystem", "8. pushOrder(order)  (deep copy into orders[])"),
 ("msg", "RestaurantSystem", "Bill", "9. generateBillForOrder():  new Bill(billId, orderId, subtotal)"),
 ("self", "Bill", "10. calculateTotal()  (GST 5 %, total)"),
 ("msg", "RestaurantSystem", "Order", "11. setBilled(true)"),
 ("msg", "RestaurantSystem", "Bill", "12. printBill(customerName, itemLines)"),
 ("ret", "Bill", "User", "13. bill displayed on console"),
 ("msg", "RestaurantSystem", "Payment*", "14. processPaymentForBill():  new Cash/Card/UpiPayment(...)"),
 ("msg", "RestaurantSystem", "Payment*", "15. processPayment()   [virtual - runtime polymorphism]"),
 ("ret", "Payment*", "RestaurantSystem", "16. true  (payment accepted)"),
 ("msg", "RestaurantSystem", "Bill", "17. markPaid()"),
 ("self", "RestaurantSystem", "18. pushPayment(payment)"),
 ("note", "Later: user chooses 9 (Exit)  or  8 -> Save"),
 ("msg", "User", "main()", "19. choose 9 (Exit)"),
 ("msg", "main()", "RestaurantSystem", "20. shutdown()"),
 ("msg", "RestaurantSystem", "FileManager", "21. save(*this)"),
 ("ret", "FileManager", "RestaurantSystem", "22. menu / customers / orders / bills / payments .txt written"),
]
sequence("Sequence_Diagram_1_Main_Transaction.png",
         "Sequence Diagram 1 - Main Transaction: Order -> Bill -> Payment -> Save",
         parts, steps, width=17)

# ====================== SEQUENCE DIAGRAM 2 : PROCESS PAYMENT ==================
parts2 = [("Cashier", "<<actor>>"), ("RestaurantSystem", None), ("InputHelper", None),
          ("Payment*", "<<abstract>>"), ("Cash/Card/UpiPayment", "<<concrete>>"),
          ("Bill", None)]
steps2 = [
 ("msg", "Cashier", "RestaurantSystem", "1. Pay a pending bill (6 -> 4), enter bill ID"),
 ("self", "RestaurantSystem", "2. findBillIndex(id);  reject if already paid"),
 ("msg", "RestaurantSystem", "Cashier", "3. show amount due, ask mode: 1 Cash / 2 Card / 3 UPI"),
 ("msg", "Cashier", "RestaurantSystem", "4. select mode"),
 ("frame", "loop  [max 3 attempts]"),
 ("msg", "RestaurantSystem", "InputHelper", "5. readDouble() / readLine()  (cash / card no. / UPI id)"),
 ("ret", "InputHelper", "RestaurantSystem", "6. validated text"),
 ("msg", "RestaurantSystem", "Cash/Card/UpiPayment", "7. Payment* p = new XxxPayment(id, billId, amount, data)"),
 ("msg", "RestaurantSystem", "Payment*", "8. p->processPayment()   [late binding]"),
 ("msg", "Payment*", "Cash/Card/UpiPayment", "9. dispatch to the overriding version"),
 ("frame", "alt  [details valid]"),
 ("ret", "Cash/Card/UpiPayment", "RestaurantSystem", "10. return true  (change / last4 / upi stored)"),
 ("msg", "RestaurantSystem", "Bill", "11. markPaid()"),
 ("self", "RestaurantSystem", "12. pushPayment(p)  -> payments[]"),
 ("ret", "RestaurantSystem", "Cashier", "13. PAYMENT SUCCESSFUL + details"),
 ("else", "[invalid details]"),
 ("ret", "Cash/Card/UpiPayment", "RestaurantSystem", "14. throw PaymentException(message)"),
 ("self", "RestaurantSystem", "15. catch -> delete p;  show error"),
 ("msg", "RestaurantSystem", "Cashier", "16. 'Try again? (y/n)'  -> loop repeats / bill stays PENDING"),
 ("end",),
 ("end",),
]
sequence("Sequence_Diagram_2_Process_Payment.png",
         "Sequence Diagram 2 - Process Payment (Runtime Polymorphism + Exception Handling)",
         parts2, steps2, width=17)
print("ok")
