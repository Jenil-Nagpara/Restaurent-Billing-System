/*
 * FileManager.cpp
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 */
#include "FileManager.h"
#include "RestaurantSystem.h"
#include "BillingException.h"

#include <fstream>
#include <iostream>
#include <filesystem>

namespace fs = std::filesystem;

static const char* MENU_FILE     = "menu.txt";
static const char* CUSTOMER_FILE = "customers.txt";
static const char* ORDER_FILE    = "orders.txt";
static const char* BILL_FILE     = "bills.txt";
static const char* PAYMENT_FILE  = "payments.txt";

FileManager::FileManager(const std::string& directory) : dataDir(directory) {}

std::string FileManager::pathOf(const std::string& fileName) const {
    return (fs::path(dataDir) / fileName).string();
}

std::vector<std::string> FileManager::split(const std::string& line, char delim) {
    std::vector<std::string> parts;
    std::string cur;
    for (char c : line) {
        if (c == delim) { parts.push_back(cur); cur.clear(); }
        else cur += c;
    }
    parts.push_back(cur);
    return parts;
}

bool FileManager::dataExists() const {
    return fs::exists(pathOf(MENU_FILE));
}

// ------------------------------------------------------------------- SAVE
void FileManager::save(const RestaurantSystem& s) const {
    std::error_code ec;
    fs::create_directories(dataDir, ec);

    auto open = [&](const char* name) {
        std::ofstream f(pathOf(name), std::ios::trunc);
        if (!f.is_open()) throw FileException(std::string("Cannot write file: ") + pathOf(name));
        return f;
    };

    { std::ofstream f = open(MENU_FILE);
      for (int i = 0; i < s.menuCount; ++i)  f << s.menu[i]->toFileString() << "\n";      // virtual call
      if (!f) throw FileException("Error while writing menu file."); }

    { std::ofstream f = open(CUSTOMER_FILE);
      for (int i = 0; i < s.customerCount; ++i) f << s.customers[i].toFileString() << "\n";
      if (!f) throw FileException("Error while writing customer file."); }

    { std::ofstream f = open(ORDER_FILE);
      for (int i = 0; i < s.orderCount; ++i) f << s.orders[i].toFileString() << "\n";
      if (!f) throw FileException("Error while writing order file."); }

    { std::ofstream f = open(BILL_FILE);
      for (int i = 0; i < s.billCount; ++i) f << s.bills[i].toFileString() << "\n";
      if (!f) throw FileException("Error while writing bill file."); }

    { std::ofstream f = open(PAYMENT_FILE);
      for (int i = 0; i < s.paymentCount; ++i) f << s.payments[i]->toFileString() << "\n"; // virtual call
      if (!f) throw FileException("Error while writing payment file."); }
}

// ------------------------------------------------------------------- LOAD
int FileManager::load(RestaurantSystem& s) const {
    int skipped = 0;
    std::string line;

    // ---- menu items ----
    { std::ifstream f(pathOf(MENU_FILE));
      while (std::getline(f, line)) {
          if (line.empty()) continue;
          try {
              auto p = split(line, '|');
              if (p.size() != 5) throw std::runtime_error("bad field count");
              int id = std::stoi(p[1]);  double price = std::stod(p[3]);
              if (p[0] == "F")      s.pushMenuItem(new FoodItem(id, p[2], price, p[4] == "1"));
              else if (p[0] == "B") s.pushMenuItem(new BeverageItem(id, p[2], price, std::stoi(p[4])));
              else throw std::runtime_error("unknown item type");
          } catch (const std::exception&) { ++skipped; }
      } }

    // ---- customers ----
    { std::ifstream f(pathOf(CUSTOMER_FILE));
      while (std::getline(f, line)) {
          if (line.empty()) continue;
          try {
              auto p = split(line, '|');
              if (p.size() != 3) throw std::runtime_error("bad field count");
              s.pushCustomer(Customer(std::stoi(p[0]), p[1], p[2]));
          } catch (const std::exception&) { ++skipped; }
      } }

    // ---- orders ----
    { std::ifstream f(pathOf(ORDER_FILE));
      while (std::getline(f, line)) {
          if (line.empty()) continue;
          try {
              auto p = split(line, '|');
              if (p.size() != 5) throw std::runtime_error("bad field count");
              Order o(std::stoi(p[0]), std::stoi(p[1]));
              o.setDateTime(p[2]);
              o.setBilled(p[3] == "1");
              for (const std::string& part : split(p[4], ';')) {
                  if (part.empty()) continue;
                  auto q = split(part, ':');
                  if (q.size() != 3) throw std::runtime_error("bad order line");
                  o.addItem(std::stoi(q[0]), std::stoi(q[1]), std::stod(q[2]));
              }
              s.pushOrder(o);
          } catch (const std::exception&) { ++skipped; }
      } }

    // ---- bills ----
    { std::ifstream f(pathOf(BILL_FILE));
      while (std::getline(f, line)) {
          if (line.empty()) continue;
          try {
              auto p = split(line, '|');
              if (p.size() != 7) throw std::runtime_error("bad field count");
              s.pushBill(Bill(std::stoi(p[0]), std::stoi(p[1]), std::stod(p[2]), std::stod(p[3]),
                              std::stod(p[4]), p[5] == "1", p[6]));
          } catch (const std::exception&) { ++skipped; }
      } }

    // ---- payments (polymorphic restore) ----
    { std::ifstream f(pathOf(PAYMENT_FILE));
      while (std::getline(f, line)) {
          if (line.empty()) continue;
          try {
              auto p = split(line, '|');
              if (p.size() < 6) throw std::runtime_error("bad field count");
              int pid = std::stoi(p[1]), bid = std::stoi(p[2]);
              double amt = std::stod(p[3]);
              Payment* pay = nullptr;
              if (p[0] == "C" && p.size() == 7)
                  pay = new CashPayment(pid, bid, amt, p[4], std::stod(p[5]), std::stod(p[6]));
              else if (p[0] == "D" && p.size() == 6) pay = new CardPayment(pid, bid, amt, p[4], p[5]);
              else if (p[0] == "U" && p.size() == 6) pay = new UpiPayment(pid, bid, amt, p[4], p[5]);
              else throw std::runtime_error("unknown payment type");
              s.pushPayment(pay);
          } catch (const std::exception&) { ++skipped; }
      } }

    return skipped;
}
