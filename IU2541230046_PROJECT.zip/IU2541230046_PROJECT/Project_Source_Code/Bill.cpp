/*
 * Bill.cpp
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 */
#include "Bill.h"
#include "InputHelper.h"

#include <iostream>
#include <iomanip>
#include <sstream>

Bill::Bill() : billId(0), orderId(0), subtotal(0), tax(0), total(0), paid(false), dateTime("") {}

Bill::Bill(int bid, int oid, double sub)
    : billId(bid), orderId(oid), subtotal(sub), tax(0), total(0), paid(false),
      dateTime(InputHelper::nowString()) {
    calculateTotal();
}

Bill::Bill(int bid, int oid, double sub, double taxAmt, double totalAmt,
           bool isPaid, const std::string& dt)
    : billId(bid), orderId(oid), subtotal(sub), tax(taxAmt), total(totalAmt),
      paid(isPaid), dateTime(dt) {}

Bill::~Bill() {}

void Bill::calculateTotal() {
    tax   = InputHelper::round2(subtotal * TAX_RATE);
    total = InputHelper::round2(subtotal + tax);
}

void Bill::printBill(const std::string& customerName, const std::string& itemLines) const {
    std::cout << std::fixed << std::setprecision(2);
    std::cout << "\n==============================================================\n"
              << "                    RESTAURANT BILLING SYSTEM\n"
              << "                       TAX INVOICE / BILL\n"
              << "==============================================================\n"
              << " Bill No  : " << billId  << "          Order No : " << orderId << "\n"
              << " Date     : " << dateTime << "\n"
              << " Customer : " << customerName << "\n"
              << "--------------------------------------------------------------\n"
              << " " << std::left << std::setw(26) << "Item" << std::setw(6) << "Qty"
              << std::right << std::setw(12) << "Rate" << std::setw(14) << "Amount" << "\n"
              << "--------------------------------------------------------------\n"
              << itemLines
              << "--------------------------------------------------------------\n"
              << std::right
              << std::setw(46) << "Subtotal :" << std::setw(14) << subtotal << "\n"
              << std::setw(46) << "GST (5%) :" << std::setw(14) << tax << "\n"
              << std::setw(46) << "GRAND TOTAL (Rs.) :" << std::setw(14) << total << "\n"
              << "--------------------------------------------------------------\n"
              << " Payment Status : " << (paid ? "PAID" : "PENDING") << "\n"
              << "==============================================================\n"
              << "              Thank you! Please visit again.\n" << std::left;
}

void Bill::printHeader() {
    std::cout << "+--------+--------+------------+----------+------------+----------+\n"
              << "| Bill   | Order  | Subtotal   | GST      | Total (Rs) | Status   |\n"
              << "+--------+--------+------------+----------+------------+----------+\n";
}

void Bill::display() const {
    std::cout << "| " << std::left << std::setw(6) << billId
              << " | " << std::setw(6) << orderId
              << " | " << std::right << std::fixed << std::setprecision(2)
              << std::setw(10) << subtotal
              << " | " << std::setw(8) << tax
              << " | " << std::setw(10) << total
              << " | " << std::left << std::setw(8) << (paid ? "Paid" : "Pending") << " |\n";
}

std::string Bill::toFileString() const {
    std::ostringstream os;
    os << billId << "|" << orderId << "|" << std::fixed << std::setprecision(2)
       << subtotal << "|" << tax << "|" << total << "|" << (paid ? 1 : 0) << "|" << dateTime;
    return os.str();
}
