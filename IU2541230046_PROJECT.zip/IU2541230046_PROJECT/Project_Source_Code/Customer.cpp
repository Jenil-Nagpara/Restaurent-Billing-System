/*
 * Customer.cpp
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 */
#include "Customer.h"
#include "BillingException.h"
#include "InputHelper.h"

#include <iostream>
#include <iomanip>
#include <sstream>

Customer::Customer() : customerId(0), name(""), phone("") {}

Customer::Customer(int id, const std::string& custName, const std::string& custPhone)
    : customerId(id), name(custName), phone(custPhone) {}

Customer::~Customer() {}

void Customer::setName(const std::string& newName) {
    if (!InputHelper::isValidPersonName(newName))
        throw ValidationException("Invalid customer name.");
    name = newName;
}

void Customer::setPhone(const std::string& newPhone) {
    if (!InputHelper::isValidPhone(newPhone))
        throw ValidationException("Phone must be 10 digits starting with 6-9.");
    phone = newPhone;
}

void Customer::printHeader() {
    std::cout << "+--------+--------------------------------+------------+\n"
              << "| ID     | Name                           | Phone      |\n"
              << "+--------+--------------------------------+------------+\n";
}

void Customer::display() const {
    std::cout << "| " << std::left << std::setw(6) << customerId
              << " | " << std::setw(30) << InputHelper::truncate(name, 30)
              << " | " << std::setw(10) << phone << " |\n";
}

std::string Customer::toFileString() const {
    std::ostringstream os;
    os << customerId << "|" << name << "|" << phone;
    return os.str();
}
