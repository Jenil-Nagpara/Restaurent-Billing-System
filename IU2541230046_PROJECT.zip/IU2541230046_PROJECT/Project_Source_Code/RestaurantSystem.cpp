/*
 * RestaurantSystem.cpp
 * Project  : Restaurant Billing System (CPP27)
 * Student  : Jenil Nagpara   |   Enrollment No.: IU2541230046
 */
#include "RestaurantSystem.h"
#include "BillingException.h"
#include "InputHelper.h"

#include <iostream>
#include <iomanip>
#include <sstream>

using std::cout;
using namespace InputHelper;

// ---------------------------------------------------------------------------
// Generic helper: doubles the capacity of a dynamic array (new[] / delete[]).
// ---------------------------------------------------------------------------
template <typename T>
static void growArray(T*& arr, int& cap, int count) {
    int newCap = (cap == 0) ? 8 : cap * 2;
    T* bigger = new T[newCap];                     // allocate larger block
    for (int i = 0; i < count; ++i) bigger[i] = arr[i];
    delete[] arr;                                  // release the old block
    arr = bigger;
    cap = newCap;
}

// ============================== construction ================================
RestaurantSystem::RestaurantSystem(const std::string& dataDir)
    : menu(nullptr), menuCount(0), menuCap(0),
      customers(nullptr), customerCount(0), customerCap(0),
      orders(nullptr), orderCount(0), orderCap(0),
      bills(nullptr), billCount(0), billCap(0),
      payments(nullptr), paymentCount(0), paymentCap(0),
      nextItemId(101), nextCustomerId(1001), nextOrderId(5001),
      nextBillId(9001), nextPaymentId(7001),
      fileManager(dataDir) {
    menuCap = customerCap = orderCap = billCap = paymentCap = 8;
    menu      = new MenuItem*[menuCap];            // dynamic memory allocated here
    customers = new Customer[customerCap];
    orders    = new Order[orderCap];
    bills     = new Bill[billCap];
    payments  = new Payment*[paymentCap];
}

RestaurantSystem::~RestaurantSystem() {
    for (int i = 0; i < menuCount; ++i)    delete menu[i];       // virtual destructors run
    for (int i = 0; i < paymentCount; ++i) delete payments[i];
    delete[] menu;
    delete[] customers;
    delete[] orders;
    delete[] bills;
    delete[] payments;
}

void RestaurantSystem::clearAll() {
    for (int i = 0; i < menuCount; ++i)    delete menu[i];
    for (int i = 0; i < paymentCount; ++i) delete payments[i];
    menuCount = customerCount = orderCount = billCount = paymentCount = 0;
    nextItemId = 101; nextCustomerId = 1001; nextOrderId = 5001;
    nextBillId = 9001; nextPaymentId = 7001;
}

// ============================== push helpers ================================
void RestaurantSystem::pushMenuItem(MenuItem* item) {
    if (menuCount == menuCap) growArray(menu, menuCap, menuCount);
    menu[menuCount++] = item;
    if (item->getItemId() >= nextItemId) nextItemId = item->getItemId() + 1;
}

void RestaurantSystem::pushCustomer(const Customer& c) {
    if (customerCount == customerCap) growArray(customers, customerCap, customerCount);
    customers[customerCount++] = c;
    if (c.getCustomerId() >= nextCustomerId) nextCustomerId = c.getCustomerId() + 1;
}

void RestaurantSystem::pushOrder(const Order& o) {
    if (orderCount == orderCap) growArray(orders, orderCap, orderCount);
    orders[orderCount++] = o;                       // deep copy via operator=
    if (o.getOrderId() >= nextOrderId) nextOrderId = o.getOrderId() + 1;
}

void RestaurantSystem::pushBill(const Bill& b) {
    if (billCount == billCap) growArray(bills, billCap, billCount);
    bills[billCount++] = b;
    if (b.getBillId() >= nextBillId) nextBillId = b.getBillId() + 1;
}

void RestaurantSystem::pushPayment(Payment* p) {
    if (paymentCount == paymentCap) growArray(payments, paymentCap, paymentCount);
    payments[paymentCount++] = p;
    if (p->getPaymentId() >= nextPaymentId) nextPaymentId = p->getPaymentId() + 1;
}

void RestaurantSystem::seedSampleMenu() {
    pushMenuItem(new FoodItem(101, "Paneer Tikka",    220.00, true));
    pushMenuItem(new FoodItem(102, "Veg Biryani",     180.00, true));
    pushMenuItem(new FoodItem(103, "Butter Chicken",  320.00, false));
    pushMenuItem(new FoodItem(104, "Masala Dosa",     120.00, true));
    pushMenuItem(new FoodItem(105, "Garlic Naan",      45.00, true));
    pushMenuItem(new FoodItem(106, "Dal Makhani",     190.00, true));
    pushMenuItem(new FoodItem(107, "Chicken Biryani", 260.00, false));
    pushMenuItem(new FoodItem(108, "Veg Sandwich",     90.00, true));
    pushMenuItem(new BeverageItem(109, "Masala Chai",       40.00, 200));
    pushMenuItem(new BeverageItem(110, "Cold Coffee",      110.00, 300));
    pushMenuItem(new BeverageItem(111, "Fresh Lime Soda",   70.00, 350));
    pushMenuItem(new BeverageItem(112, "Mango Lassi",        90.00, 300));
}

// ================================ lookups ===================================
int RestaurantSystem::findMenuIndex(int id) const {
    for (int i = 0; i < menuCount; ++i) if (menu[i]->getItemId() == id) return i;
    return -1;
}
int RestaurantSystem::findMenuByName(const std::string& name) const {
    for (int i = 0; i < menuCount; ++i) if (toLower(menu[i]->getName()) == toLower(name)) return i;
    return -1;
}
int RestaurantSystem::findCustomerIndex(int id) const {
    for (int i = 0; i < customerCount; ++i) if (customers[i].getCustomerId() == id) return i;
    return -1;
}
int RestaurantSystem::findOrderIndex(int id) const {
    for (int i = 0; i < orderCount; ++i) if (orders[i].getOrderId() == id) return i;
    return -1;
}
int RestaurantSystem::findBillIndex(int id) const {
    for (int i = 0; i < billCount; ++i) if (bills[i].getBillId() == id) return i;
    return -1;
}
int RestaurantSystem::findBillByOrder(int orderId) const {
    for (int i = 0; i < billCount; ++i) if (bills[i].getOrderId() == orderId) return i;
    return -1;
}
std::string RestaurantSystem::customerNameOf(int customerId) const {
    int i = findCustomerIndex(customerId);
    return i >= 0 ? customers[i].getName() : "(deleted customer)";
}
std::string RestaurantSystem::itemNameOf(int itemId) const {
    int i = findMenuIndex(itemId);
    return i >= 0 ? menu[i]->getName() : "(removed item)";
}

std::string RestaurantSystem::buildItemLines(const Order& o) const {
    std::ostringstream os;
    os << std::fixed << std::setprecision(2);
    for (int i = 0; i < o.getItemCount(); ++i) {
        double line = o.getQuantity(i) * o.getUnitPrice(i);
        os << " " << std::left << std::setw(26) << truncate(itemNameOf(o.getItemId(i)), 25)
           << std::setw(6) << o.getQuantity(i)
           << std::right << std::setw(12) << o.getUnitPrice(i)
           << std::setw(14) << line << "\n";
    }
    return os.str();
}

// true if the customer has an order that is not yet fully paid
bool RestaurantSystem::hasPendingWork(int customerId) const {
    for (int i = 0; i < orderCount; ++i) {
        if (orders[i].getCustomerId() != customerId) continue;
        int b = findBillByOrder(orders[i].getOrderId());
        if (b < 0 || !bills[b].isPaid()) return true;
    }
    return false;
}

// ============================== startup / shutdown ==========================
void RestaurantSystem::startup() {
    if (fileManager.dataExists()) {
        int skipped = fileManager.load(*this);
        cout << "[OK] Saved data loaded from '" << fileManager.getDirectory() << "/': "
             << menuCount << " menu items, " << customerCount << " customers, "
             << orderCount << " orders, " << billCount << " bills, "
             << paymentCount << " payments.\n";
        if (skipped > 0) cout << "[!] " << skipped << " corrupted line(s) were skipped while loading.\n";
    } else {
        seedSampleMenu();
        cout << "[INFO] No saved data found (first run). A sample menu of "
             << menuCount << " items has been loaded.\n";
    }
}

void RestaurantSystem::shutdown() {
    fileManager.save(*this);
    cout << "[OK] All records saved to '" << fileManager.getDirectory() << "/'.\n";
}

// ================================ 1. ADD ====================================
void RestaurantSystem::addRecord() {
    cout << "\n--- ADD RECORD ---\n"
         << "  1. Menu Item\n  2. Customer\n  0. Back\n"
         << "  (Orders / Bills / Payments are created through option 6)\n";
    int c = readInt("Choice: ", 0, 2);
    if (c == 1) addMenuItem();
    else if (c == 2) addCustomer();
}

void RestaurantSystem::addMenuItem() {
    cout << "  Item type:  1. Food   2. Beverage\n";
    int type = readInt("  Type: ", 1, 2);
    std::string name = readItemName("  Item name: ");
    if (findMenuByName(name) >= 0)
        throw ValidationException("A menu item named '" + name + "' already exists.");
    double price = readDouble("  Price (Rs.): ", 1.0, MenuItem::MAX_PRICE);

    MenuItem* item = nullptr;                      // base-class pointer
    if (type == 1) {
        bool veg = readYesNo("  Vegetarian? (y/n): ");
        item = new FoodItem(nextItemId, name, price, veg);
    } else {
        int ml = readInt("  Size in ml (50-1000): ", 50, 1000);
        item = new BeverageItem(nextItemId, name, price, ml);
    }
    pushMenuItem(item);
    cout << "[OK] Menu item added with ID " << item->getItemId() << ".\n";
}

void RestaurantSystem::addCustomer() {
    std::string name  = readPersonName("  Customer name: ");
    std::string phone = readPhone("  Phone (10 digits): ");
    for (int i = 0; i < customerCount; ++i)
        if (customers[i].getPhone() == phone)
            throw ValidationException("A customer with this phone number already exists (ID " +
                                      std::to_string(customers[i].getCustomerId()) + ").");
    pushCustomer(Customer(nextCustomerId, name, phone));
    cout << "[OK] Customer added with ID " << customers[customerCount - 1].getCustomerId() << ".\n";
}

// ============================== 2. DISPLAY ==================================
void RestaurantSystem::displayMenu() const {
    if (menuCount == 0) { cout << "  (no menu items)\n"; return; }
    MenuItem::printHeader();
    for (int i = 0; i < menuCount; ++i) menu[i]->display();     // runtime polymorphism
    cout << "+--------+--------------------------------+-----------+---------+------------+\n";
}
void RestaurantSystem::displayCustomers() const {
    if (customerCount == 0) { cout << "  (no customers)\n"; return; }
    Customer::printHeader();
    for (int i = 0; i < customerCount; ++i) customers[i].display();
    cout << "+--------+--------------------------------+------------+\n";
}
void RestaurantSystem::displayOrders() const {
    if (orderCount == 0) { cout << "  (no orders)\n"; return; }
    Order::printHeader();
    for (int i = 0; i < orderCount; ++i) orders[i].display();
    cout << "+--------+-------------+------------------+-------+------------+----------+\n";
}
void RestaurantSystem::displayBills() const {
    if (billCount == 0) { cout << "  (no bills)\n"; return; }
    Bill::printHeader();
    for (int i = 0; i < billCount; ++i) bills[i].display();
    cout << "+--------+--------+------------+----------+------------+----------+\n";
}
void RestaurantSystem::displayPayments() const {
    if (paymentCount == 0) { cout << "  (no payments)\n"; return; }
    Payment::printHeader();
    for (int i = 0; i < paymentCount; ++i) payments[i]->display();   // runtime polymorphism
    cout << "+--------+--------+--------+------------+------------------+--------------------------------+\n";
}

void RestaurantSystem::displayRecords() const {
    cout << "\n--- DISPLAY RECORDS ---\n"
         << "  1. Menu Items\n  2. Customers\n  3. Orders\n  4. Bills\n  5. Payments\n"
         << "  6. Everything\n  0. Back\n";
    int c = readInt("Choice: ", 0, 6);
    switch (c) {
        case 1: cout << "\n"; displayMenu();      break;
        case 2: cout << "\n"; displayCustomers(); break;
        case 3: cout << "\n"; displayOrders();    break;
        case 4: cout << "\n"; displayBills();     break;
        case 5: cout << "\n"; displayPayments();  break;
        case 6:
            cout << "\n[MENU]\n";      displayMenu();
            cout << "\n[CUSTOMERS]\n"; displayCustomers();
            cout << "\n[ORDERS]\n";    displayOrders();
            cout << "\n[BILLS]\n";     displayBills();
            cout << "\n[PAYMENTS]\n";  displayPayments();
            break;
        default: break;
    }
}

void RestaurantSystem::printOrderDetails(const Order& o) const {
    cout << std::fixed << std::setprecision(2);
    cout << "\nOrder No : " << o.getOrderId() << "   Date: " << o.getDateTime() << "\n"
         << "Customer : " << o.getCustomerId() << " - " << customerNameOf(o.getCustomerId()) << "\n"
         << "Status   : " << (o.isBilled() ? "Billed" : "Open (not billed yet)") << "\n"
         << "--------------------------------------------------------------\n"
         << " " << std::left << std::setw(26) << "Item" << std::setw(6) << "Qty"
         << std::right << std::setw(12) << "Rate" << std::setw(14) << "Amount" << "\n"
         << "--------------------------------------------------------------\n"
         << buildItemLines(o)
         << "--------------------------------------------------------------\n"
         << std::right << std::setw(46) << "Order total (before GST) :" << std::setw(14) << o.getTotal() << "\n"
         << std::left;
}

// ================================ 3. SEARCH =================================
void RestaurantSystem::searchRecord() const {
    cout << "\n--- SEARCH RECORD ---\n"
         << "  1. Menu item by ID\n  2. Menu item by name\n  3. Customer by ID\n"
         << "  4. Customer by name / phone\n  5. Order by ID\n  6. Bill by ID\n  0. Back\n";
    int c = readInt("Choice: ", 0, 6);
    if (c == 0) return;

    if (c == 1) {
        int id = readInt("Enter menu item ID: ", 1, 999999);
        int i = findMenuIndex(id);
        if (i < 0) throw NotFoundException("No menu item with ID " + std::to_string(id) + ".");
        cout << "\n"; MenuItem::printHeader(); menu[i]->display();
        cout << "+--------+--------------------------------+-----------+---------+------------+\n";
    } else if (c == 2) {
        std::string key = readLine("Enter name (or part of name): ");
        int found = 0;
        for (int i = 0; i < menuCount; ++i) {
            if (containsIgnoreCase(menu[i]->getName(), key)) {
                if (found == 0) { cout << "\n"; MenuItem::printHeader(); }
                menu[i]->display(); ++found;
            }
        }
        if (found == 0) throw NotFoundException("No menu item matches '" + key + "'.");
        cout << "+--------+--------------------------------+-----------+---------+------------+\n"
             << found << " record(s) found.\n";
    } else if (c == 3) {
        int id = readInt("Enter customer ID: ", 1, 999999);
        int i = findCustomerIndex(id);
        if (i < 0) throw NotFoundException("No customer with ID " + std::to_string(id) + ".");
        cout << "\n"; Customer::printHeader(); customers[i].display();
        cout << "+--------+--------------------------------+------------+\n";
    } else if (c == 4) {
        std::string key = readLine("Enter name or phone (or part of it): ");
        int found = 0;
        for (int i = 0; i < customerCount; ++i) {
            if (containsIgnoreCase(customers[i].getName(), key) ||
                customers[i].getPhone().find(key) != std::string::npos) {
                if (found == 0) { cout << "\n"; Customer::printHeader(); }
                customers[i].display(); ++found;
            }
        }
        if (found == 0) throw NotFoundException("No customer matches '" + key + "'.");
        cout << "+--------+--------------------------------+------------+\n"
             << found << " record(s) found.\n";
    } else if (c == 5) {
        int id = readInt("Enter order ID: ", 1, 999999);
        int i = findOrderIndex(id);
        if (i < 0) throw NotFoundException("No order with ID " + std::to_string(id) + ".");
        printOrderDetails(orders[i]);
    } else {
        int id = readInt("Enter bill ID: ", 1, 999999);
        int i = findBillIndex(id);
        if (i < 0) throw NotFoundException("No bill with ID " + std::to_string(id) + ".");
        printBillAt(i);
    }
}

// ================================ 4. UPDATE =================================
void RestaurantSystem::updateRecord() {
    cout << "\n--- UPDATE RECORD ---\n  1. Menu Item\n  2. Customer\n  0. Back\n";
    int c = readInt("Choice: ", 0, 2);
    if (c == 1) updateMenuItem();
    else if (c == 2) updateCustomer();
}

void RestaurantSystem::updateMenuItem() {
    int id = readInt("Enter menu item ID to update: ", 1, 999999);
    int i = findMenuIndex(id);
    if (i < 0) throw NotFoundException("No menu item with ID " + std::to_string(id) + ".");
    cout << "\nCurrent record:\n"; MenuItem::printHeader(); menu[i]->display();
    cout << "+--------+--------------------------------+-----------+---------+------------+\n";
    cout << "  1. Change name\n  2. Change price\n  0. Cancel\n";
    int c = readInt("What to update: ", 0, 2);
    if (c == 1) {
        std::string n = readItemName("  New name: ");
        int dup = findMenuByName(n);
        if (dup >= 0 && dup != i) throw ValidationException("Another item already uses that name.");
        menu[i]->setName(n);
        cout << "[OK] Name updated.\n";
    } else if (c == 2) {
        double p = readDouble("  New price (Rs.): ", 1.0, MenuItem::MAX_PRICE);
        menu[i]->setPrice(p);
        cout << "[OK] Price updated. (Existing orders keep their old price.)\n";
    }
}

void RestaurantSystem::updateCustomer() {
    int id = readInt("Enter customer ID to update: ", 1, 999999);
    int i = findCustomerIndex(id);
    if (i < 0) throw NotFoundException("No customer with ID " + std::to_string(id) + ".");
    cout << "\nCurrent record:\n"; Customer::printHeader(); customers[i].display();
    cout << "+--------+--------------------------------+------------+\n";
    cout << "  1. Change name\n  2. Change phone\n  0. Cancel\n";
    int c = readInt("What to update: ", 0, 2);
    if (c == 1) {
        customers[i].setName(readPersonName("  New name: "));
        cout << "[OK] Name updated.\n";
    } else if (c == 2) {
        std::string ph = readPhone("  New phone (10 digits): ");
        for (int k = 0; k < customerCount; ++k)
            if (k != i && customers[k].getPhone() == ph)
                throw ValidationException("That phone number belongs to another customer.");
        customers[i].setPhone(ph);
        cout << "[OK] Phone updated.\n";
    }
}

// ================================ 5. DELETE =================================
void RestaurantSystem::deleteRecord() {
    cout << "\n--- DELETE RECORD ---\n  1. Menu Item\n  2. Customer\n  3. Cancel an unpaid Order\n  0. Back\n";
    int c = readInt("Choice: ", 0, 3);
    if (c == 1) deleteMenuItem();
    else if (c == 2) deleteCustomer();
    else if (c == 3) deleteOrder();
}

void RestaurantSystem::deleteMenuItem() {
    int id = readInt("Enter menu item ID to delete: ", 1, 999999);
    int i = findMenuIndex(id);
    if (i < 0) throw NotFoundException("No menu item with ID " + std::to_string(id) + ".");
    if (!readYesNo("Delete '" + menu[i]->getName() + "'? (y/n): ")) { cout << "Cancelled.\n"; return; }
    delete menu[i];                                   // release the object
    for (int k = i; k < menuCount - 1; ++k) menu[k] = menu[k + 1];
    --menuCount;
    cout << "[OK] Menu item deleted.\n";
}

void RestaurantSystem::deleteCustomer() {
    int id = readInt("Enter customer ID to delete: ", 1, 999999);
    int i = findCustomerIndex(id);
    if (i < 0) throw NotFoundException("No customer with ID " + std::to_string(id) + ".");
    if (hasPendingWork(id))
        throw ValidationException("Customer has unpaid orders/bills and cannot be deleted.");
    if (!readYesNo("Delete customer '" + customers[i].getName() + "'? (y/n): ")) { cout << "Cancelled.\n"; return; }
    for (int k = i; k < customerCount - 1; ++k) customers[k] = customers[k + 1];
    --customerCount;
    cout << "[OK] Customer deleted.\n";
}

void RestaurantSystem::deleteOrder() {
    int id = readInt("Enter order ID to cancel: ", 1, 999999);
    int i = findOrderIndex(id);
    if (i < 0) throw NotFoundException("No order with ID " + std::to_string(id) + ".");
    int b = findBillByOrder(id);
    if (b >= 0 && bills[b].isPaid())
        throw ValidationException("This order is already paid and cannot be cancelled.");
    if (!readYesNo("Cancel order " + std::to_string(id) + "? (y/n): ")) { cout << "Cancelled.\n"; return; }
    if (b >= 0) {                                      // remove its unpaid bill first
        for (int k = b; k < billCount - 1; ++k) bills[k] = bills[k + 1];
        --billCount;
    }
    for (int k = i; k < orderCount - 1; ++k) orders[k] = orders[k + 1];   // deep copies
    --orderCount;
    cout << "[OK] Order cancelled" << (b >= 0 ? " (its unpaid bill was removed too)." : ".") << "\n";
}

// ====================== 6. MAIN TRANSACTION / PROCESS =======================
void RestaurantSystem::mainTransaction() {
    cout << "\n--- MAIN TRANSACTION : ORDER -> BILL -> PAYMENT ---\n"
         << "  1. Complete billing flow (new order + bill + payment)\n"
         << "  2. Take a new order only\n"
         << "  3. Generate bill for an existing order\n"
         << "  4. Pay a pending bill\n"
         << "  5. Reprint a bill\n  0. Back\n";
    int c = readInt("Choice: ", 0, 5);
    if (c == 0) return;

    if (c == 1) {
        int oi = takeNewOrder();
        if (oi < 0) return;
        int bi = generateBillForOrder(oi);
        if (readYesNo("\nProceed to payment now? (y/n): ")) processPaymentForBill(bi);
        else cout << "Bill kept as PENDING. Pay it later from option 6 -> 4.\n";
    } else if (c == 2) {
        takeNewOrder();
    } else if (c == 3) {
        int id = readInt("Enter order ID: ", 1, 999999);
        int oi = findOrderIndex(id);
        if (oi < 0) throw NotFoundException("No order with ID " + std::to_string(id) + ".");
        generateBillForOrder(oi);
    } else if (c == 4) {
        int id = readInt("Enter bill ID: ", 1, 999999);
        int bi = findBillIndex(id);
        if (bi < 0) throw NotFoundException("No bill with ID " + std::to_string(id) + ".");
        processPaymentForBill(bi);
    } else {
        int id = readInt("Enter bill ID: ", 1, 999999);
        int bi = findBillIndex(id);
        if (bi < 0) throw NotFoundException("No bill with ID " + std::to_string(id) + ".");
        printBillAt(bi);
    }
}

int RestaurantSystem::takeNewOrder() {
    if (menuCount == 0) throw ValidationException("Menu is empty. Add menu items first.");

    int cid = readInt("Customer ID (0 = register a new customer): ", 0, 999999);
    if (cid == 0) {
        addCustomer();
        cid = customers[customerCount - 1].getCustomerId();
    } else if (findCustomerIndex(cid) < 0) {
        throw NotFoundException("No customer with ID " + std::to_string(cid) + ".");
    }

    Order order(nextOrderId, cid);
    cout << "\n"; displayMenu();
    cout << std::fixed << std::setprecision(2);
    while (true) {
        int id = readInt("Item ID to add (0 = finish): ", 0, 999999);
        if (id == 0) break;
        int mi = findMenuIndex(id);
        if (mi < 0) { cout << "  [!] No such menu item. Try again.\n"; continue; }
        int qty = readInt("  Quantity (1-50): ", 1, Order::MAX_QTY_PER_LINE);
        try {
            order.addItem(id, qty, menu[mi]->getPrice());
            cout << "  + " << qty << " x " << menu[mi]->getName()
                 << "   | running total: Rs. " << order.getTotal() << "\n";
        } catch (const ValidationException& e) {
            cout << "  [!] " << e.what() << "\n";
        }
    }
    if (order.getItemCount() == 0) {
        cout << "No items were added. Order cancelled.\n";
        return -1;
    }
    order.calculateTotal();
    pushOrder(order);
    cout << "[OK] Order " << order.getOrderId() << " created for " << customerNameOf(cid)
         << ". Order total: Rs. " << order.getTotal() << "\n";
    return orderCount - 1;
}

int RestaurantSystem::generateBillForOrder(int orderIndex) {
    Order& o = orders[orderIndex];
    if (o.isBilled()) {
        int b = findBillByOrder(o.getOrderId());
        throw ValidationException("Order " + std::to_string(o.getOrderId()) +
                                  " is already billed (Bill " + (b >= 0 ? std::to_string(bills[b].getBillId()) : "?") + ").");
    }
    Bill bill(nextBillId, o.getOrderId(), o.calculateTotal());
    bill.calculateTotal();
    o.setBilled(true);
    pushBill(bill);
    printBillAt(billCount - 1);
    return billCount - 1;
}

void RestaurantSystem::printBillAt(int billIndex) const {
    const Bill& b = bills[billIndex];
    int oi = findOrderIndex(b.getOrderId());
    if (oi < 0) throw NotFoundException("Order of this bill no longer exists.");
    b.printBill(customerNameOf(orders[oi].getCustomerId()), buildItemLines(orders[oi]));
}

void RestaurantSystem::processPaymentForBill(int billIndex) {
    Bill& bill = bills[billIndex];
    if (bill.isPaid())
        throw ValidationException("Bill " + std::to_string(bill.getBillId()) + " is already paid.");

    double due = bill.getTotal();
    cout << std::fixed << std::setprecision(2)
         << "\nBill " << bill.getBillId() << " - amount due: Rs. " << due << "\n"
         << "  1. Cash\n  2. Card\n  3. UPI\n  0. Cancel (keep bill pending)\n";
    int mode = readInt("Select payment mode: ", 0, 3);
    if (mode == 0) { cout << "Payment cancelled. Bill remains PENDING.\n"; return; }

    int attempts = 0;
    while (true) {
        Payment* pay = nullptr;                        // base-class pointer
        try {
            if (mode == 1) {
                double tendered = readDouble("  Cash tendered (Rs.): ", 0.0, 1000000.0);
                pay = new CashPayment(nextPaymentId, bill.getBillId(), due, tendered);
            } else if (mode == 2) {
                std::string card = readLine("  Card number (16 digits): ");
                pay = new CardPayment(nextPaymentId, bill.getBillId(), due, card);
            } else {
                std::string upi = readLine("  UPI ID (e.g. name@bank): ");
                pay = new UpiPayment(nextPaymentId, bill.getBillId(), due, upi);
            }

            pay->processPayment();                     // RUNTIME POLYMORPHISM: Cash/Card/UPI version runs

            cout << "\n[OK] PAYMENT SUCCESSFUL\n"
                 << "     Payment ID : " << pay->getPaymentId() << "\n"
                 << "     Mode       : " << pay->getMode() << "\n"
                 << "     Amount     : Rs. " << pay->getAmount() << "\n"
                 << "     Details    : " << pay->getDetails() << "\n";
            pushPayment(pay);                          // ownership moves to the system
            pay = nullptr;
            bill.markPaid();
            return;
        } catch (const PaymentException& e) {
            delete pay;                                // free the failed payment object
            pay = nullptr;
            cout << "  [!] Payment failed: " << e.what() << "\n";
            if (++attempts >= 3) {
                cout << "Too many failed attempts. Bill remains PENDING.\n";
                return;
            }
            if (!readYesNo("  Try again? (y/n): ")) {
                cout << "Bill remains PENDING.\n";
                return;
            }
        } catch (...) {
            delete pay;                                // never leak on any other error
            throw;
        }
    }
}

// ================================ 7. REPORT =================================
void RestaurantSystem::generateReport() const {
    cout << std::fixed << std::setprecision(2);

    int paidBills = 0, pendingBills = 0;
    double revenue = 0, tax = 0, pending = 0;
    for (int i = 0; i < billCount; ++i) {
        if (bills[i].isPaid()) { ++paidBills; revenue += bills[i].getTotal(); tax += bills[i].getTax(); }
        else { ++pendingBills; pending += bills[i].getTotal(); }
    }
    double byCash = 0, byCard = 0, byUpi = 0;
    for (int i = 0; i < paymentCount; ++i) {
        if (payments[i]->getMode() == "Cash") byCash += payments[i]->getAmount();
        else if (payments[i]->getMode() == "Card") byCard += payments[i]->getAmount();
        else byUpi += payments[i]->getAmount();
    }

    cout << "\n==================== SALES REPORT ====================\n"
         << " Menu items        : " << menuCount << "\n"
         << " Customers         : " << customerCount << "\n"
         << " Orders            : " << orderCount << "\n"
         << " Bills             : " << billCount << "  (Paid: " << paidBills << ", Pending: " << pendingBills << ")\n"
         << "------------------------------------------------------\n"
         << " Total revenue (paid bills) : Rs. " << revenue << "\n"
         << " GST collected              : Rs. " << tax << "\n"
         << " Pending amount             : Rs. " << pending << "\n"
         << "------------------------------------------------------\n"
         << " Revenue by payment mode\n"
         << "   Cash : Rs. " << byCash << "\n"
         << "   Card : Rs. " << byCard << "\n"
         << "   UPI  : Rs. " << byUpi  << "\n";

    // ---- item-wise sales: temporary DYNAMIC arrays sized to the menu ----
    if (menuCount > 0) {
        int*    qtySold = new int[menuCount]();         // () -> zero-initialised
        double* amount  = new double[menuCount]();
        for (int o = 0; o < orderCount; ++o)
            for (int l = 0; l < orders[o].getItemCount(); ++l) {
                int mi = findMenuIndex(orders[o].getItemId(l));
                if (mi >= 0) {
                    qtySold[mi] += orders[o].getQuantity(l);
                    amount[mi]  += orders[o].getQuantity(l) * orders[o].getUnitPrice(l);
                }
            }
        cout << "------------------------------------------------------\n"
             << " Item-wise sales (all orders)\n"
             << "   " << std::left << std::setw(26) << "Item" << std::setw(8) << "Qty"
             << std::right << std::setw(14) << "Amount (Rs)" << "\n";
        int best = -1;
        for (int i = 0; i < menuCount; ++i) {
            if (qtySold[i] == 0) continue;
            cout << "   " << std::left << std::setw(26) << truncate(menu[i]->getName(), 25)
                 << std::setw(8) << qtySold[i] << std::right << std::setw(14) << amount[i] << "\n";
            if (best < 0 || qtySold[i] > qtySold[best]) best = i;
        }
        if (best < 0) cout << "   (no sales yet)\n";
        else cout << " Best-selling item : " << menu[best]->getName() << " (" << qtySold[best] << " sold)\n";
        delete[] qtySold;                               // release temporary arrays
        delete[] amount;
    }

    // ---- top customer by paid amount ----
    int topCust = -1; double topAmt = 0;
    for (int c = 0; c < customerCount; ++c) {
        double sum = 0;
        for (int o = 0; o < orderCount; ++o) {
            if (orders[o].getCustomerId() != customers[c].getCustomerId()) continue;
            int b = findBillByOrder(orders[o].getOrderId());
            if (b >= 0 && bills[b].isPaid()) sum += bills[b].getTotal();
        }
        if (sum > topAmt) { topAmt = sum; topCust = c; }
    }
    cout << "------------------------------------------------------\n";
    if (topCust >= 0) cout << " Top customer      : " << customers[topCust].getName()
                           << " (Rs. " << topAmt << ")\n";
    else cout << " Top customer      : (no paid bills yet)\n";
    cout << "======================================================\n" << std::left;
}

// ============================== 8. SAVE / LOAD ==============================
void RestaurantSystem::saveLoadMenu() {
    cout << "\n--- SAVE / LOAD ---\n  1. Save all records to files\n"
         << "  2. Load records from files (replaces data currently in memory)\n  0. Back\n";
    int c = readInt("Choice: ", 0, 2);
    if (c == 1) {
        fileManager.save(*this);
        cout << "[OK] Saved: " << menuCount << " menu items, " << customerCount << " customers, "
             << orderCount << " orders, " << billCount << " bills, " << paymentCount << " payments.\n";
    } else if (c == 2) {
        if (!fileManager.dataExists())
            throw FileException("No saved data found in '" + fileManager.getDirectory() + "/'. Save first.");
        if (!readYesNo("Unsaved changes in memory will be lost. Continue? (y/n): ")) { cout << "Cancelled.\n"; return; }
        clearAll();
        int skipped = fileManager.load(*this);
        cout << "[OK] Loaded: " << menuCount << " menu items, " << customerCount << " customers, "
             << orderCount << " orders, " << billCount << " bills, " << paymentCount << " payments.\n";
        if (skipped > 0) cout << "[!] " << skipped << " corrupted line(s) skipped.\n";
    }
}
